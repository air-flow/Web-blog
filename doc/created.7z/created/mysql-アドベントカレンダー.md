# 目次
[:contents]

# 初めに

この記事は[MySQL Advent Calendar 2020の14日目の記事](https://qiita.com/advent-calendar/2020/mysql)です。

アドベントカレンダー参加は、初めてなので至らないところもあるとは思いますが、寛容な心でご覧ください。

# とある日

https://dev.mysql.com/doc/refman/8.0/en/with.html#common-table-expressions-recursion-limits

1. ```
   character_set_client
   check_proxy_users
   collation_connection
   collation_server
   completion_type
   cte_max_recursion_depth
   default_week_format
   div_precision_increment
   general_log
   group_concat_max_len	
   log_error
   	lower_case_file_system
   lower_case_table_names
   	max_error_count
   ```

# my.cnf概要



>[foreign_key_checks](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_foreign_key_checks)
>
>1（デフォルト）に設定すると、外部キー制約がチェックされます。0に設定すると、いくつかの例外を除いて、外部キー制約は無視されます。ドロップされたテーブルを再作成するときに、テーブル定義がテーブルを参照する外部キー制約に準拠していない場合、エラーが返されます。同様に、[`ALTER TABLE`](https://dev.mysql.com/doc/refman/8.0/en/alter-table.html) 外部キー定義が正しく形成されていない場合、操作はエラーを返します。詳細については、[13.1.20.5項「外部キーの制約」を](https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html)参照してください 。
>
>この変数を設定すると、[`NDB`](https://dev.mysql.com/doc/refman/8.0/en/mysql-cluster.html)テーブルの場合と同じ効果 が `InnoDB`テーブルにあります。通常、[参照整合性](https://dev.mysql.com/doc/refman/8.0/en/glossary.html#glos_referential_integrity)を適用するには、通常の操作中にこの設定を有効のままにし [ます](https://dev.mysql.com/doc/refman/8.0/en/glossary.html#glos_referential_integrity)。外部キーチェックを無効に`InnoDB`すると、親子関係で必要な順序とは異なる順序でテーブルを再ロードする場合に役立ちます。[セクション13.1.20.5「外部キーの制約」を](https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html)参照してください 。
>
>`foreign_key_checks`0に 設定すると、データ定義ステートメントにも影響 [`DROP SCHEMA`](https://dev.mysql.com/doc/refman/8.0/en/drop-database.html)します。スキーマ外のテーブルによって参照される外部キーを持つテーブルが含まれている場合でもスキーマを[`DROP TABLE`](https://dev.mysql.com/doc/refman/8.0/en/drop-table.html) 削除し、他のテーブルによって参照される外部キーを持つテーブルを削除します。
>
>



# 実験環境のmy.cnf紹介



# 〆



# 参考

https://gihyo.jp/dev/serial/01/mysql-road-construction-news/0031

https://dev.mysql.com/doc/refman/8.0/en/performance-schema-variables-info-table.html

https://dev.mysql.com/doc/refman/5.6/ja/option-files.html

https://dev.mysql.com/doc/refman/5.6/ja/server-system-variables.html