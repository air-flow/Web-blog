# 目次
[:contents]

# とある日

**Python**や他の言語でも実装するとファイル参照などのときに手間が減るかもしれない方法。

# No such file or directory

ファイル読み込みなどのプログラムを書いていると`PATH`が間違ってそんなファイルは存在しないというエラーをみたことがある人は多いだろう。

各有自分もよくやっていた。

今回はそのエラーを回避する方法を記述する。

## エラー原因

今回エラー回避できる**`FileNotFoundError`**について少し補足します。

今回の手法で回避エラー原因は**カレントディレクトリと実行ファイル内の読み込みファイルの`PATH`**に差異があるため発生するエラーに関してのみ回避することができます。

詳しく説明すると。

下記のようなディレクトリ構造になっている場合。

<div class="code-title" data-title="bash">
```bash
C:.
├─Current_Directory
└─python
        python.py
        read.txt
```
</div>

そして、`python.py`には下記のような`read.txt`を読み込むような記述があった場合。

<div class="code-title" data-title="python">
```python
with open("./read.txt", mode="r", encoding="utf-8") as f:
    l = f.readlines()
```
</div>

`pyhon`のディレクトリで`python.py`を実行すると問題なく`read.txt`を読み込む事が可能です。

**しかし、`Current_Directory`に移動して実行すると`FileNotFoundError: [Errno 2] No such file or directory`が出力されます。**

これを回避する方法があるのです。

# Change Directory

方法は簡単下記の関数を導入して呼び出すだけ。

<div class="code-title" data-title="python">
```python
import os
def cd():
    os.chdir(os.path.dirname(__file__))
```
</div>

少し解説。

`python.py`に当てはめて考えます。

| 名称              | 意味                                     | 値                   |
| ----------------- | ---------------------------------------- | -------------------- |
| `__file__`        | 実行中のファイルの場所（パス）を取得する | `C/python/python.py` |
| `os.path.dirname` | フォルダ名（ディレクトリ名）を取得する   | `C/python`           |
| `os.chdir`        | カレントディレクトリを変更               | `C/python`           |

文章で説明すると、`__file__`で実行ファイルの絶対PATHを取得して、そのPATHをもとにそのファイル格納フォルダのディレクトリを`os.path.dirname`  で取得。

最後に、そのディレクトリに`os.chdir`で移動するといった内容。

これをすることによって、カレントディレクトリを気にすることなく、ファイルを実行することができる。

考えるのは、実行ファイルから読み込むファイルの相対パスのみ。

# 全体像

<div class="code-title" data-title="python">
```python
import os


def cd():
    os.chdir(os.path.dirname(__file__))


if __name__ == "__main__":
    cd()

    with open("./read.txt", mode="r", encoding="utf-8") as f:
        l = f.readlines()
```
</div>

ファイル読み込みの前に実行する必要がある。

# 〆

簡単な内容ですが、これをすることによって毎回カレントディレクトリを変更する必要がなくなるので少し便利になります。

`VSCode`だと、スニペットが登録できるので`cd`などで登録しておくと、毎回記述する手間やコピーする手間が省けます。