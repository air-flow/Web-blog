

# 目次
[:contents]

# とある日

zabbix5.2を初めて構築してて躓いたエラーの解決方法を記述します。

# 前提条件

この記事を見る方は大きく2つの用途があると思います。

そのぞれの方向けに前提条件を記述します。

**Zabbix**の構築で躓いた方は条件に適合するかどうかをチェックしてください。

同様のError Messageで躓いた方は、サービスごとで具体的なパラメータが異なるのですが、エラーの解決の根底方法はわかると思います。

自分がそうでしたので。

一応、WSL2でDockerの中でZabbixを構築しています。

## Zabbix

初めに、Zabbix構築で必要なアプリケーションのバージョンを明記します。

理由としては、Zabbixのバージョンでも、OSのバージョンでも異なると構築手順が変わります。

**特に、ZabbixのバージョンとOSのバージョンは一致させたものを参考にすることをおすすめします。**

- Zabbix 5.2
- CentOS7
- MySQL8.0.24
- PHP 7.4

[Zabbix構築参考記事](https://server-recipe.com/3158/#toc5)

自分が参考にした記事です。

**Zabbix5.2をCentOS7で構築を考えているかは落ち着いてください。（自分がそうでした）**

**Zabbix5.2をCentOS7でYUMインストールを行っている方はできないそうです。**

> CentOS7にyum でインストールできる最新版は、Zabbix 5.0です。
> 最新版の、Zabbix 5.2 を、yumでインストールできるのは、CentOS8になります。
> つまり、CentOS7では、前のバージョンの、Zabbix 5.0しかありません。
> Zabbix 5.2の最新版を、CentOS7に入れるには、ソースからインストールするしかありません。

上記の理由もあるので、Zabbixの構築で躓いている方はもう一度ZabbixとOSのバージョンを確認してください。

## Error Message

**このエラーメッセージは、どのサービスを構築しているかで見るファイルが異なります。**

自分は、Zabbixを構築しているときに発生したエラーです。

サービス特有のファイルのパラメータだけ変えれば解決すると思われます。

下記にエラーメッセージの全容を載せておきます。

<div class="code-title" data-title="bash">
```bash
[root@e2234e5cf739 /]# systemctl status zabbix-server
● zabbix-server.service - Zabbix Server
   Loaded: loaded (/usr/lib/systemd/system/zabbix-server.service; disabled; vendor preset: disabled)
   Active: activating (start) since Sat 2021-05-08 01:25:19 UTC; 45s ago
  Process: 192 ExecStart=/usr/local/sbin/zabbix_server -c $CONFFILE (code=exited, status=0/SUCCESS)
   CGroup: /docker/e2234e5cf7393acd9e06b745beb7e8fd0c21ed47f91e9b271c63854d7ba5e884/system.slice/zabbix-server.service
           ├─194 /usr/local/sbin/zabbix_server -c /usr/local/etc/zabbix_server.conf
           ├─197 /usr/local/sbin/zabbix_server: configuration syncer [synced configuration in 0.110889 sec, idle 60 sec]
           ├─198 /usr/local/sbin/zabbix_server: housekeeper [startup idle for 30 minutes]
           ├─199 /usr/local/sbin/zabbix_server: timer #1 [updated 0 hosts, suppressed 0 events in 0.000447 sec, idle 59 sec]
           ├─200 /usr/local/sbin/zabbix_server: http poller #1 [got 0 values in 0.000588 sec, idle 5 sec]
           ├─201 /usr/local/sbin/zabbix_server: discoverer #1 [processed 0 rules in 0.001534 sec, idle 60 sec]
           ├─203 /usr/local/sbin/zabbix_server: history syncer #1 [processed 0 values, 0 triggers in 0.000030 sec, idle 1 sec]
           ├─205 /usr/local/sbin/zabbix_server: history syncer #2 [processed 0 values, 0 triggers in 0.000017 sec, idle 1 sec]
           ├─207 /usr/local/sbin/zabbix_server: history syncer #3 [processed 0 values, 0 triggers in 0.000019 sec, idle 1 sec]
           ├─209 /usr/local/sbin/zabbix_server: history syncer #4 [processed 0 values, 0 triggers in 0.000016 sec, idle 1 sec]
           ├─211 /usr/local/sbin/zabbix_server: escalator #1 [processed 0 escalations in 0.000666 sec, idle 3 sec]
           ├─212 /usr/local/sbin/zabbix_server: proxy poller #1 [exchanged data with 0 proxies in 0.000025 sec, idle 5 sec]
           ├─214 /usr/local/sbin/zabbix_server: self-monitoring [processed data in 0.000012 sec, idle 1 sec]
           ├─216 /usr/local/sbin/zabbix_server: task manager [processed 0 task(s) in 0.000292 sec, idle 5 sec]
           ├─217 /usr/local/sbin/zabbix_server: poller #1 [got 0 values in 0.000008 sec, idle 1 sec]
           ├─219 /usr/local/sbin/zabbix_server: poller #2 [got 0 values in 0.000009 sec, idle 1 sec]
           ├─220 /usr/local/sbin/zabbix_server: poller #3 [got 0 values in 0.000008 sec, idle 1 sec]
           ├─221 /usr/local/sbin/zabbix_server: poller #4 [got 0 values in 0.000025 sec, idle 1 sec]
           ├─222 /usr/local/sbin/zabbix_server: poller #5 [got 0 values in 0.000009 sec, idle 1 sec]
           ├─223 /usr/local/sbin/zabbix_server: unreachable poller #1 [got 0 values in 0.000019 sec, idle 5 sec]
           ├─224 /usr/local/sbin/zabbix_server: trapper #1 [processed data in 0.000000 sec, waiting for connection]
           ├─225 /usr/local/sbin/zabbix_server: trapper #2 [processed data in 0.000000 sec, waiting for connection]
           ├─226 /usr/local/sbin/zabbix_server: trapper #3 [processed data in 0.000000 sec, waiting for connection]
           ├─227 /usr/local/sbin/zabbix_server: trapper #4 [processed data in 0.000000 sec, waiting for connection]
           ├─228 /usr/local/sbin/zabbix_server: trapper #5 [processed data in 0.000000 sec, waiting for connection]
           ├─229 /usr/local/sbin/zabbix_server: icmp pinger #1 [got 0 values in 0.000015 sec, idle 5 sec]
           ├─230 /usr/local/sbin/zabbix_server: alert manager #1 [sent 0, failed 0 alerts, idle 5.005519 sec during 5.005594 sec]
           ├─231 /usr/local/sbin/zabbix_server: alerter #1 started
           ├─232 /usr/local/sbin/zabbix_server: alerter #2 started
           ├─233 /usr/local/sbin/zabbix_server: alerter #3 started
           ├─234 /usr/local/sbin/zabbix_server: preprocessing manager #1 [queued 0, processed 7 values, idle 5.002514 sec during 5.002806 sec]
           ├─235 /usr/local/sbin/zabbix_server: preprocessing worker #1 started
           ├─236 /usr/local/sbin/zabbix_server: preprocessing worker #2 started
           ├─237 /usr/local/sbin/zabbix_server: preprocessing worker #3 started
           ├─238 /usr/local/sbin/zabbix_server: lld manager #1 [processed 0 LLD rules, idle 5.005639sec during 5.005697 sec]
           ├─239 /usr/local/sbin/zabbix_server: lld worker #1 started
           ├─240 /usr/local/sbin/zabbix_server: lld worker #2 started
           └─241 /usr/local/sbin/zabbix_server: alert syncer [queued 0 alerts(s), flushed 0 result(s) in 0.000985 sec, idle 1 sec]

May 08 01:25:19 e2234e5cf739 systemd[1]: Starting Zabbix Server...
May 08 01:25:19 e2234e5cf739 systemd[1]: New main PID 194 does not belong to service, and PID file is not owned by root. Refusing.
May 08 01:25:19 e2234e5cf739 systemd[1]: New main PID 194 does not belong to service, and PID file is not owned by root. Refusing.

```
</div>

# 解決方法

**サービスの起動ファイルの特定のパラメータを削除またはコメントアウトすると解決します。**

[New main PID does not belong to service, and PID file is not owned by root](https://askubuntu.com/questions/1044464/new-main-pid-does-not-belong-to-service-and-pid-file-is-not-owned-by-root)

**↑解決方法発見に至った記事。**

> Commenting out PAMName=login solved the issue on 16.04
> 翻訳↓
> PAMName=loginをコメントアウトすると、16.04で問題が解決しました。



[Starting a service fails with "New main PID does not belong to service, and PID file is not owned by root. Refusing"](https://access.redhat.com/solutions/4420581)

**↑解決に至った記事。**

> ## Issue
>
> - Since the upgrade to RHEL 7.7, a service with property `Type=forking` and property `PIDFile` defined doesn't start and its status shows the following error messages:
>
> ## 問題
>
> - RHEL 7.7へのアップグレード以降、プロパティ`Type=forking`とプロパティが`PIDFile`定義されたサービスは開始されず、そのステータスには次のエラーメッセージが表示されます。
>
>   

Zabbix-Server起動する前に、起動ファイルを作成しました。

<div class="code-title" data-title="bash">
```bash
vi /usr/lib/systemd/system/zabbix-server.service

[Unit]
Description=Zabbix Server
After=syslog.target
After=network.target
After=mysql.service
After=mysqld.service
[Service]
Environment="CONFFILE=/usr/local/etc/zabbix_server.conf"
EnvironmentFile=-/etc/sysconfig/zabbix-server
Type=forking
Restart=on-failure
PIDFile=/tmp/zabbix_server.pid
KillMode=control-group
ExecStart=/usr/local/sbin/zabbix_server -c $CONFFILE
ExecStop=/bin/kill -SIGTERM $MAINPID
RestartSec=10s
TimeoutSec=0
[Install]
WantedBy=multi-user.target
```
</div>

上記でも引用したように、**Type=forking**と**PIDFile=/tmp/zabbix_server.pid**がエラーの原因でした。

なので、削除しました。（コメントアウトってなにでするのかわからなくなったため）

<div class="code-title" data-title="bash">
```bash
[root@e2234e5cf739 /]# systemctl start zabbix-server
systemctl daemon-reload^C
[root@e2234e5cf739 /]# systemctl status zabbix-server
● zabbix-server.service - Zabbix Server
   Loaded: loaded (/usr/lib/systemd/system/zabbix-server.service; disabled; vendor preset: disabled)
   Active: activating (auto-restart) (Result: exit-code) since Sat 2021-05-08 03:00:18 UTC; 7s ago
  Process: 5181 ExecStop=/bin/kill -SIGTERM $MAINPID (code=exited, status=1/FAILURE)
  Process: 5178 ExecStart=/usr/sbin/zabbix_server -c $CONFFILE (code=exited, status=0/SUCCESS)
 Main PID: 5178 (code=exited, status=0/SUCCESS)

May 08 03:00:18 e2234e5cf739 systemd[1]: Unit zabbix-server.service entered failed state.
May 08 03:00:18 e2234e5cf739 systemd[1]: zabbix-server.service failed.
```
</div>

**`systemctl start zabbix-server`**するとプロセス起動の状態でコマンドプロンプトが正常に表示されないのでCtrl+Cで無理やり閉じてます。

statusの結果は問題ない。

ほかのサービスのstatusと違って、 **`Active: activating (auto-restart)`**や  **`Loaded: loaded`**という表示になる。

最初わからなくて、何度もstartしていた。

# 〆

めちゃくちゃ躓いたけどなんとかZabbixの管理画面まで表示することができた。

しかし、当初の予定の5.2ではなく、5.0が表示される。

途中で、5.2のインストールができなくて5.0をrpmでインストールを行った結果管理画面では5.0が表示される。

しかし、サーバーのZabbixバージョンは5.2になっている。

Zabbix難しすぎる。

# 参考記事

https://server-recipe.com/3158/#toc5

https://www.zabbix.com/documentation/5.0/manual/installation/requirements

https://www.zabbix.com/documentation/current/manual/installation/requirements

https://www.zabbix.com/documentation/current/manual/installation/install

https://www.zabbix.com/documentation/current/manual/concepts/java/from_sourceshttps://www.zabbix.com/download?zabbix=5.0&os_distribution=centos&os_version=7&db=mysql&ws=apache

https://www.zabbix.com/documentation/2.2/jp/manual/concepts/server

https://twitter.com/jfut/status/1174528535848841217

https://askubuntu.com/questions/1044464/new-main-pid-does-not-belong-to-service-and-pid-file-is-not-owned-by-root

https://access.redhat.com/solutions/4420581



