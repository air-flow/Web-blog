# 目次
[:contents]

# とある日

趣味に使うDBがないのでVirtuallboxを使って構築する手順のメモを残す。

OS:CentOS8

DB:MySQL8.0

# CentOS8構築

GUIでインストールする。

## 1. ストレージ容量

**ストレージを8GiBから20GiBに変更。**

8GiBでやったら、足りないって言われたので。

## 2.  メモリ

2048MB

## 3.ネットワーク

アダプター１：NAT

アダプター２：ホストオンリーアダプター（VritualBox Host Only Enthernet Adapter）

## 4. GUI操作

言語：日本語設定

サーバ環境：サーバー　統合された管理が容易なサーバーです。

root password : password

create user : hobby 

create user password : hobby 

高度：group wheel 

**再起動後、CentOS8ディスクを取り出す作業が必要になる。**

取り出したら、ウインドウを閉じる。

## dnf update

dnd update 最新にしておく。



# MySQL構築

dnf list 等でMySQLのバージョンを確認する。

<div class="code-title" data-title="bash">
```bash
dnf info mysql
メタデータの期限切れの最終確認: 0:05:25 時間前の 2020年11月04日 11時34分14秒 に 実施しました。
利用可能なパッケージ
名前         : mysql
バージョン   : 8.0.21
リリース     : 1.module_el8.2.0+493+63b41e36
Arch         : x86_64
サイズ       : 12 M
ソース       : mysql-8.0.21-1.module_el8.2.0+493+63b41e36.src.rpm
リポジトリー : AppStream
概要         : MySQL client programs and shared libraries
URL          : http://www.mysql.com
ライセンス   : GPLv2 with exceptions and LGPLv2 and BSD
説明         : MySQL is a multi-user, multi-threaded SQL database server. MySQL
             : is a client/server implementation consisting of a server daemon
             : (mysqld) and many different client programs and libraries. The
             : base package contains the standard MySQL client programs and
             : generic MySQL files.

```
</div>

最新バージョンナノが確認できたら、インストールする。

## MySQLインストール

<div class="code-title" data-title="bash">
```bash
 sudo dnf install @mysql:8.0
```
</div>

関連パッケージもインストールされる。

<div class="code-title" data-title="bash">
```bash
[hobby@localhost ~]$ mysql --version
mysql  Ver 8.0.21 for Linux on x86_64 (Source distribution)
```
</div>

## MySQLの初期設定

<div class="code-title" data-title="bash">
```bash
mysql_secure_installation
```
</div>

パスワードのチェックとか設定していく。

終わったら、MySQLに接続できる。

初期設定で決めたrootのパスワードで、接続を行う。

# 〆

今後のためのメモ。

my.cnfとかんの設定もメモっておきたい。