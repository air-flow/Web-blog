# 目次
[:contents]

# とある日

https://twitter.com/MySQL/status/1384624438679773185

先日**MySQL8.0.24**がリリースされました。

おめでとうございます。

なので、早速新しい機能とか触ってみたいと思い現環境である**MySQL8.0.23**をアップデートしようとしたときのお話。

はじめに整理されたアップデート手順を書いて、そのあとで実際はどんな感じで進めたかの話を書こうと思います。

# 環境

| 項目     | 詳細         |
| -------- | ------------ |
| DataBase | MySQL 8.0.23 |
| OS       | CentOS8      |

詳しくは下記のテスト環境の記事を参照してください。

[https://updraft.hatenadiary.com/entry/2021/01/21/075228:embed:cite]

# MySQL8.0.24アップデート手順

**MySQL8.0.23**から**MySQL8.0.24**にアップデートする手順を書いています。

5系から8.0.24のバージョンアップの仕方とは別のものになるのでご注意ください。

他にも事前インストールしたパッケージがない場合もあります。

今回行った事例が最適とは限りません。

過去に**8.0.21**から**8.0.23**にマイナーアップデートした記事もあります。

今回とは違うやり方でアップデートしています。

ご参考までに。



## 1. YUM アップデート

いろいろな依存しているパッケージを最新にアップデートする。

※リポジトリのアップデートとかなかったのであまり関係ないとは思いますが念の為パッケージを最新にする。

ダウンロード中の余分なところは削除してます。

```sh
[hobby@localhost ~]$ sudo yum update
メタデータの期限切れの最終確認: 0:37:07 時間前の 2021年04月08日 19時32分40秒 に 実施しました。

依存関係が解決しました。

インストール     5 パッケージ
アップグレード  60 パッケージ
削除             3 パッケージ

ダウンロードサイズの合計: 171 M
合計                                             11 MB/s | 171 MB     00:15
Installed products updated.

完了しました!
```

## 2. MySQL停止

必ず停止をおこなう。

あとは、バックアップをしっかりと取ることをおすすめします。

自分の環境は、Virtual Box上で管理しているのスナップショットで済ませました。

```sh
[hobby@localhost ~]$  sudo systemctl stop mysqld
```



## 3. RPMダウンロード

8.0.24のRPMパッケージをダウンロードする。

 [MySQL Community Downloads](https://dev.mysql.com/downloads/)

| Download Packages name                                       | version | size   | link                                                        |
| ------------------------------------------------------------ | ------- | ------ | ----------------------------------------------------------- |
| **Red Hat Enterprise Linux 8 / Oracle Linux 8 (x86, 64-bit), RPM Bundle** | 8.0.24  | 729.9M | [Download](https://dev.mysql.com/downloads/file/?id=502950) |

ダウンロードファイル名：mysql-8.0.24-1.el8.x86_64.rpm-bundle.tar

**Bundle**にした理由として、参考にした記事がそれを選択していたためです。

後で詳細を記述しますが、アップデートに必要としたパッケージは2つだけでした。

**Bundle**を選択しない場合は、**server**と**common**と書かれている2つをダウンロードすればいいと思います。

何も考えたくない人は全部入っている**Bundle**でいいと思います。

### 3.1 Winscpファイル転送

自分は仮想環境内でアップデートを行いたいので、

ホストPCでパッケージダウンロードしてそれをWinSCPで転送しました。

はじめはrootの配下に転送いたので、一般ユーザーディレクトリに**mysql**を作成後そこに配置。

```sh
[root@localhost hobby]# ll
合計 749932
-rw-rw-r--. 1 hobby hobby   2568430 11月 25 03:09 datadump_20201125
-rw-r--r--. 1 root  root  765358080  4月  8 21:02 mysql-8.0.24-1.el8.x86_64.rpm-bundle.tar
[root@localhost hobby]# mkdir mysql
[root@localhost hobby]# mv ./mysql-8.0.24-1.el8.x86_64.rpm-bundle.tar ./mysql
[root@localhost hobby]# ll
合計 2512
-rw-rw-r--. 1 hobby hobby 2568430 11月 25 03:09 datadump_20201125
drwxr-xr-x. 2 root  root       54  4月  8 21:05 mysql
[root@localhost hobby]# cd mysql/
[root@localhost mysql]# ll
合計 747420
-rw-r--r--. 1 root root 765358080  4月  8 21:02 mysql-8.0.24-1.el8.x86_64.rpm-bundle.tar
```



## 4. RPM展開

任意の場所で展開。

```sh
[root@localhost mysql]# tar -xvf mysql-8.0.24-1.el8.x86_64.rpm-bundle.tar
mysql-community-client-8.0.24-1.el8.x86_64.rpm
mysql-community-client-debuginfo-8.0.24-1.el8.x86_64.rpm
mysql-community-client-plugins-8.0.24-1.el8.x86_64.rpm
mysql-community-client-plugins-debuginfo-8.0.24-1.el8.x86_64.rpm
mysql-community-common-8.0.24-1.el8.x86_64.rpm
mysql-community-debuginfo-8.0.24-1.el8.x86_64.rpm
mysql-community-debugsource-8.0.24-1.el8.x86_64.rpm
mysql-community-devel-8.0.24-1.el8.x86_64.rpm
mysql-community-libs-8.0.24-1.el8.x86_64.rpm
mysql-community-libs-debuginfo-8.0.24-1.el8.x86_64.rpm
mysql-community-server-8.0.24-1.el8.x86_64.rpm
mysql-community-server-debug-8.0.24-1.el8.x86_64.rpm
mysql-community-server-debug-debuginfo-8.0.24-1.el8.x86_64.rpm
mysql-community-server-debuginfo-8.0.24-1.el8.x86_64.rpm
mysql-community-test-8.0.24-1.el8.x86_64.rpm
mysql-community-test-debuginfo-8.0.24-1.el8.x86_64.rpm
```



## 5. RPMインストール

**mysql-community-server-8.0.24-1.el8.x86_64.rpm****と **mysql-community-common-8.0.24-1.el8.x86_64.rpm**の2つをインストール。

```sh
[root@localhost mysql]# rpm -Uvh mysql-community-server-8.0.24-1.el8.x86_64.rpm  mysql-community-common-8.0.24-1.el8.x86_64.rpm
Verifying...                          ################################# [100%]
準備しています...              ################################# [100%]
更新中 / インストール中...
   1:mysql-community-common-8.0.24-1.e################################# [ 25%]
   2:mysql-community-server-8.0.24-1.e################################# [ 50%]
整理中 / 削除中...
   3:mysql-community-server-8.0.23-1.e################################# [ 75%]
   4:mysql-community-common-8.0.23-1.e################################# [100%]
[/usr/lib/tmpfiles.d/mysql.conf:23] Line references path below legacy directory /var/run/, updating /var/run/mysqld → /run/mysqld; please update the tmpfiles.d/ drop-in file accordingly.
```

### 5.1 エラー: 依存性の欠如

依存性のエラーが下記のように出た場合は、今回インストールした中にない場合は別でインストールが必要になります。

今回インストールして同ディレクトリにある場合は、上記のように空白で列挙すれば解決します。

```sh
[root@localhost mysql]# rpm -Uvh mysql-community-server-8.0.24-1.el8.x86_64.rpm
エラー: 依存性の欠如:
        mysql-community-common(x86-64) = 8.0.24-1.el8 は mysql-community-server-8.0.24-1.el8.x86_64 に必要とされています
[root@localhost mysql]# ll | grep server
-rw-r--r--. 1 7155 31415  55483196  3月 23 20:55 mysql-community-server-8.0.24-1.el8.x86_64.rpm
-rw-r--r--. 1 7155 31415  22420308  3月 23 20:56 mysql-community-server-debug-8.0.24-1.el8.x86_64.rpm
-rw-r--r--. 1 7155 31415 102088644  3月 23 20:56 mysql-community-server-debug-debuginfo-8.0.24-1.el8.x86_64.rpm
-rw-r--r--. 1 7155 31415 249417684  3月 23 20:56 mysql-community-server-debuginfo-8.0.24-1.el8.x86_64.rpm
```

### 5.2 please update the tmpfiles.d/ drop-in file accordingly.

[5. RPMインストール](#5. RPMインストール)で、最後にあるこのエラー行は軽く調べた結果**MySQL8.0.24**のアップデートに関しては問題なさそうなので今回はスルーします。

軽く翻訳すると。

> レガシーディレクトリである /var/run/ 以下のパスを参照し、 /var/run/mysqld → /run/mysqld に更新しています。これに合わせてドロップインファイルを更新してください。 tmpfiles.d/ 

今後記事にする予定です。

```sh
[/usr/lib/tmpfiles.d/mysql.conf:23] Line references path below legacy directory /var/run/, updating /var/run/mysqld → /run/mysqld; please update the tmpfiles.d/ drop-in file accordingly.
```



## 6.MySQL起動

**start**で起動。

**status**で確認。

いつもの起動より時間がかかった。

```sh
[root@localhost mysql]# systemctl start mysqld
[root@localhost mysql]# systemctl status mysqld
● mysqld.service - MySQL Server
   Loaded: loaded (/usr/lib/systemd/system/mysqld.service; enabled; vendor pres>
   Active: active (running) since Thu 2021-04-08 21:13:50 JST; 9s ago
     Docs: man:mysqld(8)
           http://dev.mysql.com/doc/refman/en/using-systemd.html
  Process: 102292 ExecStartPre=/usr/bin/mysqld_pre_systemd (code=exited, status>
 Main PID: 102319 (mysqld)
   Status: "Server is operational"
    Tasks: 38 (limit: 11412)
   Memory: 611.5M
   CGroup: /system.slice/mysqld.service
           mq102319 /usr/sbin/mysqld

 4月 08 21:13:28 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:28.2542>
 4月 08 21:13:28 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:28.3016>
 4月 08 21:13:31 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:31.3802>
 4月 08 21:13:32 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:32.7948>
 4月 08 21:13:36 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:36.1444>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.0821>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.5243>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.5247>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.5620>
 4月 08 21:13:50 localhost.localdomain systemd[1]: Started MySQL Server.
set mark: ...skipping...
● mysqld.service - MySQL Server
   Loaded: loaded (/usr/lib/systemd/system/mysqld.service; enabled; vendor pres>
   Active: active (running) since Thu 2021-04-08 21:13:50 JST; 9s ago
     Docs: man:mysqld(8)
           http://dev.mysql.com/doc/refman/en/using-systemd.html
  Process: 102292 ExecStartPre=/usr/bin/mysqld_pre_systemd (code=exited, status>
 Main PID: 102319 (mysqld)
   Status: "Server is operational"
    Tasks: 38 (limit: 11412)
   Memory: 611.5M
   CGroup: /system.slice/mysqld.service
           mq102319 /usr/sbin/mysqld

 4月 08 21:13:28 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:28.2542>
 4月 08 21:13:28 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:28.3016>
 4月 08 21:13:31 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:31.3802>
 4月 08 21:13:32 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:32.7948>
 4月 08 21:13:36 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:36.1444>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.0821>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.5243>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.5247>
 4月 08 21:13:50 localhost.localdomain mysqld[102319]: 2021-04-08T12:13:50.5620>
 4月 08 21:13:50 localhost.localdomain systemd[1]: Started MySQL Server.
```

## 7. MySQL8.0.24接続

起動できたので接続します。

`Server version: 8.0.24 MySQL Community Server - GPL`でバージョン確認できました。

```sh
[root@localhost mysql]# mysql -uroot -p
Enter password:
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 10
Server version: 8.0.24 MySQL Community Server - GPL

Copyright (c) 2000, 2021, Oracle and/or its affiliates.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql>
```

# MySQL8.0.24アップデートの道筋

ここでは、8.0.24がリリースされてからアップデートしようとしてアップデートできるまでの道のりを上で整理された手順ではなく失敗事例などを交えながら紹介します。

## 1.  過去記事

過去にアップデートする記事を書いたのでそれを参考にしようとしました。

過去に書いたアップデート手順は、yumリポジトリを最新のものにしてrpmでインストールを行いました。

想定手順は、リポジトリアップデート→mysql8.0.24インストールを考えてました。

## 2. YUMリポジトリ変更なし

今回yumリポジトリを確認したところ前回と同じ**mysql80-community-release-el8-1.noarch.rpm**でした。

しかし、このままインストールしようとすると8.0.23があると言われます。

```sh
[hobby@localhost ~]$ sudo yum repolist enabled | grep "mysql.*-community.*"
[sudo] hobby のパスワード:
mysql-connectors-community MySQL Connectors Community
mysql-tools-community      MySQL Tools Community
mysql80-community          MySQL 8.0 Community Server
```

yumで探してみてもなかった。

```sh
[hobby@localhost ~]$ yum search 8.0.24
メタデータの期限切れの最終確認: 0:00:29 時間前の 2021年04月08日 20時22分07秒 に 実施しました。
一致する項目はありませんでした。
[hobby@localhost ~]$ sudo yum install mysql-community-server-8.0.24-1.el8.x86_64.rpm
[sudo] hobby のパスワード:
メタデータの期限切れの最終確認: 0:53:33 時間前の 2021年04月08日 19時32分40秒 に 実施しました。
Can not load RPM file: mysql-community-server-8.0.24-1.el8.x86_64.rpm.
開くことができませんでした: mysql-community-server-8.0.24-1.el8.x86_64.rpm
```

`yum update`で最新にしているのでmysqlだけアップデートしようとしても問題ないと言われる。

```sh
[hobby@localhost ~]$ sudo yum update mysql-server
[sudo] hobby のパスワード:
メタデータの期限切れの最終確認: 1:02:09 時間前の 2021年04月08日 19時32分40秒 に 実施しました。
依存関係が解決しました。
行うべきことはありません。
完了しました!
```

色々と探してみる。

```sh
[hobby@localhost ~]$ sudo yum list installed | grep "^mysql"
mysql-common.x86_64                           8.0.21-1.module_el8.2.0+493+63b41e36             @AppStream
mysql-community-client.x86_64                 8.0.23-1.el8                                     @mysql80-community
mysql-community-client-plugins.x86_64         8.0.23-1.el8                                     @mysql80-community
mysql-community-common.x86_64                 8.0.23-1.el8                                     @mysql80-community
mysql-community-libs.x86_64                   8.0.23-1.el8                                     @mysql80-community
mysql-community-server.x86_64                 8.0.23-1.el8                                     @mysql80-community
mysql-errmsg.x86_64                           8.0.21-1.module_el8.2.0+493+63b41e36             @AppStream
mysql80-community-release.noarch              el8-1                                            @System
```

## 3. RPMパッケージ確認

```sh
[hobby@localhost ~]$ rpm -qa | grep mysql
mysql-community-libs-8.0.23-1.el8.x86_64
mysql-community-common-8.0.23-1.el8.x86_64
mysql-community-server-8.0.23-1.el8.x86_64
mysql-errmsg-8.0.21-1.module_el8.2.0+493+63b41e36.x86_64
mysql-community-client-plugins-8.0.23-1.el8.x86_64
mysql80-community-release-el8-1.noarch
mysql-common-8.0.21-1.module_el8.2.0+493+63b41e36.x86_64
mysql-community-client-8.0.23-1.el8.x86_64
```

アップデートや再編成等も試した。

```sh
[hobby@localhost ~]$ rpm -e mysql
エラー: パッケージ mysql はインストールされていません。
[hobby@localhost ~]$ rpm -e mysql-community-server-8.0.23-1.el8.x86_64
エラー: 依存性の欠如:
        /etc/my.cnf は (インストール済み)mysql-common-8.0.21-1.module_el8.2.0+493+63b41e36.x86_64 に必要とされています
[hobby@localhost ~]$ su -
パスワード:
[root@localhost ~]# rpm -i
rpm: インストールするパッケージが指定されていません。
[root@localhost ~]# rpm -i mysql-community-server-8.0.24-1.el8.x86_64.rpm
エラー: mysql-community-server-8.0.24-1.el8.x86_64.rpm のオープンに失敗: そのよ うなファイルやディレクトリはありません
[root@localhost ~]# rpm --rebuilddb　
rpm: --rebuilddb　: 不明なオプション
[root@localhost ~]# rpm --rebuilddb
[root@localhost ~]# rpm -qa | grep mysql
mysql-community-server-8.0.23-1.el8.x86_64
mysql-errmsg-8.0.21-1.module_el8.2.0+493+63b41e36.x86_64
mysql-community-libs-8.0.23-1.el8.x86_64
mysql-community-common-8.0.23-1.el8.x86_64
mysql80-community-release-el8-1.noarch
mysql-community-client-8.0.23-1.el8.x86_64
mysql-community-client-plugins-8.0.23-1.el8.x86_64
mysql-common-8.0.21-1.module_el8.2.0+493+63b41e36.x86_64
[root@localhost ~]# yum update
メタデータの期限切れの最終確認: 1:19:04 時間前の 2021年04月08日 19時32分40秒 に 実施しました。
依存関係が解決しました。
行うべきことはありません。
完了しました!
[root@localhost ~]# rpm -Uvh mysql-community-server-8.0.23-1.el8.x86_64
エラー: mysql-community-server-8.0.23-1.el8.x86_64 のオープンに失敗: そのような ファイルやディレクトリはありません
```

## 4. RPMパッケージのインストール手順に変更

https://www.kakiro-web.com/linux/mysql-install.html

上記の記事でRPMパッケージインストール方法があったのでこの方法を選択しました。

あとは、上で説明したとおりの手順でアップデートを完了しました。

# 〆

前回と違うやり方でアップデートを行いました。

様々なアップデートやインストール手順があるなかどれが最適がわからないので、今後の課題としたいと思います。

来週あたりから8.0.24の新機能やバグフィクスなど面白そうなものを記事にしようかと思っています。