# 初めに

この記事は[RDBMS-GIS(MySQL,PostgreSQLなど) Advent Calendar 2020](https://qiita.com/advent-calendar/2020/rdbms_gis)のエントリーです。

`MySQL8.0 GIS`を使って距離と三角形の面積求めてみた。

https://www.geogebra.org/graphing?lang=ja

# 目次
[:contents]

# とある日

ネタ探しのために、いろいろな`MySQL`の`GIS`について調べてた。

`GIS`使ったことないので、チュートリアル的内容にしようかなとか、[空間インデックス](https://dev.mysql.com/doc/refman/5.6/ja/creating-spatial-indexes.html)について調べてみるとか、[MySQL8.0にアップグレードする前に空間関数の互換性のない使用を検出する](https://mysqlserverteam.com/detecting-incompatible-use-of-spatial-functions-before-upgrading-to-mysql-8-0/)とかなどなど。

ずっと悩んでいて、[MySQL徹底入門 第4版 MySQL 8.0対応](https://www.shoeisha.co.jp/book/detail/9784798161488)を見てて、`ST_Distance`についての解説を読んでいた。

**「距離を返します」**...え、座標の距離を測るって**二点間の距離**求められるじゃん。

ってことで、`GIS`の本来の使い方ではない気もしますが、`MySQL`の`GIS`の機能を使って、**二点間の距離**や**座標三角形の面積**を求めたいと思います。



# 環境

今回それぞれ使用するアプリケーション等のバージョンを明記しています。

VirtualBox 内の仮想環境下で、MySQL を構築しています。

## Oracle VM VirtualBox

[Oracle VM VirtualBox - ダウンロード](https://www.oracle.com/jp/virtualization/technologies/vm/downloads/virtualbox-downloads.html)

| 項目名     | 値                       |
| ---------- | ------------------------ |
| バージョン | 6.0.14 r133895 (Qt5.6.2) |

## DBeaver

[DBeaver Community](https://dbeaver.io/)

| 項目名     | 値                 |
| ---------- | ------------------ |
| バージョン | 7.2.0.202008302047 |

## ホスト PC

| 項目名 | 値                                       |
| ------ | ---------------------------------------- |
| OS     | Windows 10 Home                          |
| CPU    | Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz |
| メモリ | 8.0 GB                                   |

## ゲスト PC

VirtualBox の仮想環境内に、テスト環境を構築しています。

#### OS


<div class="code-title" data-title="sh">
```sh
mysql> \! cat /etc/os-release
NAME="CentOS Linux"
VERSION="8 (Core)"
ID="centos"
ID_LIKE="rhel fedora"
VERSION_ID="8"
PLATFORM_ID="platform:el8"
PRETTY_NAME="CentOS Linux 8 (Core)"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:centos:centos:8"
HOME_URL="https://www.centos.org/"
BUG_REPORT_URL="https://bugs.centos.org/"

CENTOS_MANTISBT_PROJECT="CentOS-8"
CENTOS_MANTISBT_PROJECT_VERSION="8"
REDHAT_SUPPORT_PRODUCT="centos"
REDHAT_SUPPORT_PRODUCT_VERSION="8"

```
</div>
#### メモリ

2048MB

#### ストレージ

20.00 GB

#### MySQL

<div class="code-title" data-title="mysql">
```mysql
mysql> status;
--------------
mysql  Ver 8.0.21 for Linux on x86_64 (Source distribution)

Connection id:          27
Current database:       hobby
Current user:           root@localhost
SSL:                    Not in use
Current pager:          stdout
Using outfile:          ''
Using delimiter:        ;
Server version:         8.0.21 Source distribution
Protocol version:       10
Connection:             Localhost via UNIX socket
Server characterset:    utf8mb4
Db     characterset:    utf8mb4
Client characterset:    utf8mb4
Conn.  characterset:    utf8mb4
UNIX socket:            /var/lib/mysql/mysql.sock
Binary data as:         Hexadecimal
Uptime:                 11 hours 56 min 31 sec

Threads: 5  Questions: 1817  Slow queries: 0  Opens: 409  Flush tables: 3  Open tables: 312  Queries per second avg: 0.042
```
</div>

# 二点間の距離

[2点間の距離](https://ja.wikipedia.org/wiki/距離#2点間の距離)

>ある2点間を（道路状態や地形、建築物等を一切無視し）直線状に測ったときの長さを**直線距離**という。このとき直線距離は2点間における最短の長さ、即ち**最短距離**であり、これ以外の方法を用いて2点間の長さを測定しても、直線距離より短くなることはない。

## 公式

2次元空間の2点間の直線距離は以下の通り。

[tex:{\sqrt{(x2−x1)\^2+(y2−y1)\^2}}]

## いざ求める！

### 問題

２点*A(0, 0), B(3,3)*間の距離 

![image-20201218185625902](C:\Users\kiryu\AppData\Roaming\Typora\typora-user-images\image-20201218185625902.png)

グラフを使用して2点を表すと上記の画像の様になる。

今回はあくまでも検証のため問題は簡単にしてある。

### 2点間の距離MySQL GISバージョン

<div class="code-title" data-title="mysql">
```mysql
mysql> SELECT st_distance(st_geomfromtext('point(0 0)'),st_geomfromtext('point(3 3)')) as dist;
+-------------------+
| dist              |
+-------------------+
| 4.242640687119285 |
+-------------------+
1 row in set (0.00 sec)
```
</div>
### 2点間の距離公式バージョン

<div class="code-title" data-title="mysql">
```mysql
mysql> SELECT sqrt(pow((3 - 0),2 )+ pow((3 - 0),2)) as sq from dual ;
+-------------------+
| sq                |
+-------------------+
| 4.242640687119285 |
+-------------------+
1 row in set (0.00 sec)
```
</div>


### 解説

####  Point Class

>[ポイントクラス](https://dev.mysql.com/doc/refman/8.0/en/gis-class-point.html)
>
>A`Point`は、座標空間内の単一の場所を表すジオメトリです。
>
>**`Point` プロパティ**
>
>- X座標値。
>- Y座標値。

座標を表す点を定義する型。

`point(0 1)` → 0：X座標、1：Y座標

#### ST_GeometryFromText

> [`ST_GeometryFromText(*`wkt`* [, *`srid`* [, *`options`*\]])`](https://dev.mysql.com/doc/refman/8.0/en/gis-wkt-functions.html#function_st-geomfromtext)
>
> WKT表現とSRIDを使用して、任意のタイプのジオメトリ値を作成します。
>
> これらの関数は、このセクションの概要で説明されているように引数を処理します。

**WKT**から空間データを生成する関数 **Text** -> **Geometry**

`ST_Distance`の引数が、**Text型**ではなく**Geometry型**を求めるので変換している。

#### ST_Distance

>[ST_Distance(g1, g2 [, unit])](https://dev.mysql.com/doc/refman/8.0/en/spatial-relation-functions-object-shapes.html#function_st-distance)
>
>*`g1`* との 間の距離を返します。これ*`g2`*は、ジオメトリ引数の空間参照系（SRS）の長さの単位、または*`unit`*指定されている場合はオプションの引数の単位で測定され ます。

本題の二点間の距離を求める関数。




# 座標三角形の面積

[座標法](https://ja.wikipedia.org/wiki/%E5%BA%A7%E6%A8%99%E6%B3%95)

>**座標法**（ざひょうほう）とは、平面において[多角形](https://ja.wikipedia.org/wiki/多角形)の頂点座標によってその[面積](https://ja.wikipedia.org/wiki/面積)を求める数学的[アルゴリズム](https://ja.wikipedia.org/wiki/アルゴリズム)。[測量](https://ja.wikipedia.org/wiki/測量)における用語の一つ。 靴紐公式、靴紐の方法、靴紐のアルゴリズム、ガウスの面積公式とも呼ばれる。

## 公式

三角形の面積を求める公式は下記の通り。

[tex:{\frac{1}{2}|x1y2−x2y1+x3y1-x1y3|}]

座標平面上の３点 *(x1,y1),(x2,y2),(0,0)*を頂点とする三角形の面積は、

[tex:{\frac{1}{2}|x1y2−x2y1|}]

## いざ求める！

### 問題

*A(0,0),B(3,1),C(2,3)* を３つの頂点とする三角形の面積を求めよ。

![image-20201219135552399](C:\Users\kiryu\AppData\Roaming\Typora\typora-user-images\image-20201219135552399.png)

### 座標三角形の面積MySQL GISバージョン

<div class="code-title" data-title="mysql">
```mysql
mysql> SET @poly = 'Polygon((0 0,3 1,2 3,0 0))';
Query OK, 0 rows affected (0.00 sec)

mysql> select ST_Area(ST_GeomFromText(@poly));
+---------------------------------+
| ST_Area(ST_GeomFromText(@poly)) |
+---------------------------------+
|                             3.5 |
+---------------------------------+
1 row in set (0.00 sec)
```
</div>

### 座標三角形の面積公式バージョン

座標平面上の３点 *(x1,y1),(x2,y2),(0,0)*を頂点とする三角形の面積の求め方で行っています。

<div class="code-title" data-title="mysql">
```mysql
mysql> select 1/2 * abs(3 * 3 - 2 * 1);
+--------------------------+
| 1/2 * abs(3 * 3 - 2 * 1) |
+--------------------------+
|                   3.5000 |
+--------------------------+
1 row in set (0.00 sec)
```
</div>

### 解説

[ST_GeomFromText](#ST_GeomFromText)は先ほど紹介したので省略。

#### Polygon

>[Polygon クラス](https://dev.mysql.com/doc/refman/5.6/ja/gis-class-polygon.html)
>
>`Polygon` は、多辺の幾何図形を表す平面 `Surface` です。これは 1 個の外側の境界と 0 個以上の内側の境界で定義されますが、それらの内側の各境界によって `Polygon` 内の 1 個の穴が定義されます。
>
>**`Polygon` の例**
>
>- 地域マップで、`Polygon` オブジェクトは森林や区域などを表すことができます。

#### 使用注意

- 最初と最後で同じ点を指す必要がある

`Polygon((1 2,3 1,2 3,1 2))`

*(1 2)*が最初と最後で二回記述している。

#### ST_Area

> [`ST_Area({*`poly`*|*`mpoly`*})`](https://dev.mysql.com/doc/refman/8.0/en/gis-polygon-property-functions.html#function_st-area)
>
> 空間参照系で測定された 、`Polygon`または `MultiPolygon`引数の面積を示す倍精度数を返します 。

面積を求める関数。

# 〆

`MySQL GIS`を今回はじめて使用してみた。

初歩的内容ではあったが、`GIS`について少し理解できた。

`MySQL GIS` 5.xと8.xでは関数の仕様がぜんぜん違うので注意が必要。

読んでいただいてどうもありがとうございます。

# 参考

https://www.esrij.com/getting-started/what-is-gis/

https://qiita.com/onunu/items/59ef2c050b35773ced0d

https://dev.mysql.com/doc/refman/5.6/ja/spatial-extensions.html

https://dev.mysql.com/doc/refman/5.6/ja/spatial-analysis-functions.html

https://www.slideshare.net/sakaik/mysql80gis

https://dev.mysql.com/doc/refman/5.6/ja/spatial-function-reference.html

https://dev.mysql.com/doc/refman/8.0/en/spatial-function-reference.html

https://www.slideshare.net/sakaik/mysqlgismysql80

https://speakerdeck.com/yoshiakiyamasaki/mysql-8-dot-0-gisji-neng-tiyutoriaru-6052f01e-445a-4f55-bcda-a0e3fad06332

https://www2.slideshare.net/sakaik/mysqlmysql-cafe-6

