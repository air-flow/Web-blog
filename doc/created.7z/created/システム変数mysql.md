# 目次
[:contents]

# とある日

別の記事を作成中に、**サーバーシステム変数**についての知識が乏しいと思ったので急遽勉強した内容をoutputしようかと。

# [サーバーシステム変数](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html)

> MySQLサーバーは、その操作を構成する多くのシステム変数を維持します。各システム変数にはデフォルト値があります。システム変数は、サーバーの起動時にコマンドラインまたはオプションファイルのオプションを使用して設定できます。それらのほとんどは、[`SET`](https://dev.mysql.com/doc/refman/8.0/en/set-variable.html) ステートメントを使用して実行時に動的 に変更できます。これにより、サーバーを停止して再起動しなくても、サーバーの操作を変更できます。式でシステム変数値を使用することもできます。

MySQLのデータベースシステムを構成している値となっている。

## 参照方法

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES;	
```
</div>

実行すると600件ぐらい表示される。

様々な値が設定されている。

3つぐらい軽く紹介。

## サーバーシステム変数特選3選

気になったやつとかよく使うやつを3つほど厳選して紹介。

### [range_optimizer_max_mem_size](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_activate_all_roles_on_login)

> 範囲オプティマイザのメモリ消費の制限。値0は、「制限なし」を意味します。」オプティマイザによって検討実行計画は、レンジアクセスメソッドを使用していますが、オプティマイザは、この方法のために必要なメモリの量が制限値を超えると推定した場合は、計画を放棄し、他の計画を検討します。詳細については[、範囲最適化のためのメモリ使用の制限を](https://dev.mysql.com/doc/refman/8.0/en/range-optimization.html#range-optimization-memory-use)参照してください 。

検索を行うときに経路を探索するオプティマイザのメモリ制限のシステム変数。

これについては別で少し詳しく解説予定。

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES like 'range_optimizer_max_mem_size';
-- Variable_name               |Value  |
-- ----------------------------|-------|
-- range_optimizer_max_mem_size|8388608|
```
</div>

### [transaction_isolation ](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_transaction_isolation)

> トランザクション分離レベル。デフォルトは [`REPEATABLE-READ`](https://dev.mysql.com/doc/refman/8.0/en/innodb-transaction-isolation-levels.html#isolevel_repeatable-read)です。
>
> トランザクション分離レベルには、グローバル、セッション、次のトランザクションの3つのスコープがあります。この3スコープの実装は、後で説明するように、いくつかの非標準の分離レベル割り当てセマンティクスにつながります。
>
> 起動時にグローバルトランザクション分離レベルを設定するには、[`--transaction-isolation`](https://dev.mysql.com/doc/refman/8.0/en/server-options.html#option_mysqld_transaction-isolation) サーバーオプションを使用します。
>
> 実行時に、[`SET`](https://dev.mysql.com/doc/refman/8.0/en/set-variable.html) ステートメントを使用して分離レベルを直接設定して[`transaction_isolation`](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_transaction_isolation)システム変数に値を割り当てる か、[`SET TRANSACTION`](https://dev.mysql.com/doc/refman/8.0/en/set-transaction.html)ステートメントを使用して間接的に設定できます 。[`transaction_isolation`](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_transaction_isolation) スペースを含む分離レベル名に直接設定する場合 は、名前を引用符で囲み、スペースをダッシュに置き換えてください。たとえば、次の[`SET`](https://dev.mysql.com/doc/refman/8.0/en/set-variable.html) ステートメントを使用し てグローバル値を設定します。

DMLのSQLを実行する上で必要となる変数。

それぞれのトランザクション分離レベルの内容を把握してSQLを実行しましょう。

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES like 'transaction_isolation';
-- Variable_name        |Value          |
-- ---------------------|---------------|
-- transaction_isolation|REPEATABLE-READ|
```
</div>



### [version](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_version)

>サーバーのバージョン番号。この値には、サーバーのビルドまたは構成情報を示すサフィックスが含まれる場合もあります。`-debug`サーバーがデバッグサポートを有効にして構築されたことを示します。

MySQLのバージョンを確認するときによく使用しますね。

8系と5系だとサーバーシステム変数にも差異が存在するし関数も仕様が違う場合があるので要確認。

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES like 'version';
-- Variable_name|Value |
-- -------------|------|
-- version      |8.0.23|
```
</div>

#  SHOWVARIABLESステートメント

先ほど説明したサーバーシステム変数を参照変更するときに使用するステートメント。

<div class="code-title" data-title="mysql">
```mysql
SHOW [GLOBAL | SESSION] VARIABLES
    [LIKE 'pattern' | WHERE expr]
```
</div>

> [`SHOW VARIABLES`](https://dev.mysql.com/doc/refman/8.0/en/show-variables.html)は、MySQLシステム変数の値を示しています（ [5.1.8項「サーバーシステム変数」を](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html)参照）。このステートメントには特権は必要ありません。サーバーに接続する機能のみが必要です。

## スコープ

>[`SHOW VARIABLES`](https://dev.mysql.com/doc/refman/8.0/en/show-variables.html)オプション`GLOBAL`または`SESSION` 可変のスコープ修飾子を受け入れます。

サーバーシステム変数には、`GLOBAL`または`SESSION`が存在する。

それぞれで変数の有効範囲に違いが存在する。

### GLOBAL

> `GLOBAL`修飾子、ステートメントは、グローバルシステム変数の値を表示します。これらは、MySQLへの新しい接続に対応するセッション変数を初期化するために使用される値です。変数にグローバル値がない場合、値は表示されません。

### SESSION

> `SESSION`修飾子、文は現在の接続のために有効になっているシステム変数の値を表示します。変数にセッション値がない場合は、グローバル値が表示されます。`LOCAL`はの同義語です`SESSION`。



### デフォルト値

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES like 'version';
```
</div>

[SHOW VARIABLES](https://dev.mysql.com/doc/refman/8.0/en/show-variables.html)、どちら`GLOBAL`も指定しないと`SESSION`、MySQLは`SESSION`値を返します。

## 検索

サーバーシステム変数は多数存在するので、SQL同様`WHERE句`や`LIKE句`が使用できる。

### LIKE句検索（完全一致）

特定の変数名を指定するときに使用する。

SELECT句として使用する際は、列名を指定するが**`show variables`**は指定しない。

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES LIKE 'max_join_size';
-- Variable_name|Value               |
-- -------------|--------------------|
-- max_join_size|18446744073709551615|
```
</div>

### LIKE句検索（ワイルドカード検索）

前方一致や後方一致などLIKEでできることができる。

名前があやふやなときや、単語を含む一覧を取得するときに使用。

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES LIKE '%size%';
-- Variable_name                                           |Value               |
-- --------------------------------------------------------|--------------------|
-- binlog_cache_size                                       |32768               |
-- binlog_row_event_max_size                               |8192                |
-- binlog_stmt_cache_size                                  |32768               |
-- binlog_transaction_dependency_history_size              |25000               |
-- bulk_insert_buffer_size                                 |8388608             |
-- delayed_queue_size                                      |1000                |
```
</div>

### WHERE句

2つの列に対して値を指定できる。

`BETWEEN`や`OR`、`AND`が使用できる。

そんなに使うことなさそう。

<div class="code-title" data-title="mysql">
```mysql
SHOW VARIABLES WHERE value > 0;
-- Variable_name                                           |Value               |
-- --------------------------------------------------------|--------------------|
-- admin_port                                              |33062               |
-- auto_increment_increment                                |1                   |
-- auto_increment_offset                                   |1                   |
-- back_log                                                |151                 |
-- binlog_cache_size                                       |32768               |

SHOW VARIABLES WHERE Variable_name = 'range_optimizer_max_mem_size';
-- Variable_name               |Value  |
-- ----------------------------|-------|
-- range_optimizer_max_mem_size|8388608|
```
</div>

# 〆

今回は簡易的に調べた内容を記事にした。

MySQLを触る上で必要となる知識である。

今後一つ一つに変数について知見を広げたいなあ。