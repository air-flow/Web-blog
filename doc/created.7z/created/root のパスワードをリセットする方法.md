# 目次
[:contents]

# とある日

MySQL5系の環境で検証したいことがあったので過去の仮想環境を探しててあったので、MySQLをrootで接続しようとしたら...

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# mysql -u root -p
Enter password:
ERROR 1045 (28000): Access denied for user 'root'@'localhost' (using password: YES)
```
</div>

違うパスワードだった。

これはrootのパスワードがわからないのでパスワードリセットしようとした男の物語である。

# MySQL存在確認

上記では、いきなりMySQLに接続しようとしているがそもそもはMySQLの環境を探していたのでその経緯から記述していく。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# mysql --version
mysql  Ver 15.1 Distrib 5.5.60-MariaDB, for Linux (x86_64) using readline 5.1
```
</div>

基礎的だが、MySQLを起動する前にバージョンを確認することが久しぶりで忘れていたオプション。

ここで、MariaDBだと気づく。

だが、MySQLとMariaDBはあまり違いがないのでそのまま進めます。

## サービス確認

`systemctl`コマンドで確認可能。

MariaDBのためサービス名を`mariadb`にする必要ありけり。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# systemctl status mariadb
● mariadb.service - MariaDB database server
   Loaded: loaded (/usr/lib/systemd/system/mariadb.service; enabled; vendor preset: disabled)
   Active: active (running) since Fri 2021-03-26 10:27:14 JST; 1h 12min ago
  Process: 5273 ExecStartPost=/usr/libexec/mariadb-wait-ready $MAINPID (code=exited, status=0/SUCCESS)
  Process: 5242 ExecStartPre=/usr/libexec/mariadb-prepare-db-dir %n (code=exited, status=0/SUCCESS)
 Main PID: 5272 (mysqld_safe)
   CGroup: /system.slice/mariadb.service
           tq5272 /bin/sh /usr/bin/mysqld_safe --basedir=/usr
           mq5436 /usr/libexec/mysqld --basedir=/usr --datadir=/var/lib/mysql --plugin-dir=/usr/lib64/mysql/plugin --log-error=/var/log/mariadb/mariadb.log --pid-file=/var/run/mariadb/ma...

Mar 26 10:27:12 localhost.localdomain systemd[1]: Starting MariaDB database server...
Mar 26 10:27:12 localhost.localdomain mariadb-prepare-db-dir[5242]: Database MariaDB is probably initialized in /var/lib/mysql already, nothing is done.
Mar 26 10:27:12 localhost.localdomain mysqld_safe[5272]: 210326 10:27:12 mysqld_safe Logging to '/var/log/mariadb/mariadb.log'.
Mar 26 10:27:12 localhost.localdomain mysqld_safe[5272]: 210326 10:27:12 mysqld_safe Starting mysqld daemon with databases from /var/lib/mysql
Mar 26 10:27:14 localhost.localdomain systemd[1]: Started MariaDB database server.
```
</div>

ちなみに、サービス名をmysqlで指定するとエラーになります。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# systemctl status mysql
Unit mysql.service could not be found.
```
</div>

# root password 初期化

https://www.virment.com/reset-root-password-mysql/

この記事を参考に進めました。

## サービス停止

サービスをどれを停止するのかわからないので全部試した。

`mariadb`が正解でした。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# systemctl stop mysql
Failed to stop mysql.service: Unit mysql.service not loaded.
[root@localhost ~]# systemctl stop mysqld
Failed to stop mysqld.service: Unit mysqld.service not loaded.
[root@localhost ~]# systemctl stop mariadb
```
</div>

## セーフティーモード起動

[B.5.4.1.3 root のパスワードのリセット: 一般的な手順](https://dev.mysql.com/doc/refman/5.6/ja/resetting-permissions.html#resetting-permissions-unix)

>**mysqld** を停止し、`--skip-grant-tables` オプションを指定して再起動します。これにより、だれでもパスワードなしで接続できるようになり、すべての権限が付与されます。これはセキュアではないため、リモートクライアントによる接続を回避するために、`--skip-networking` と組み合わせて `--skip-grant-tables` を使用する必要がある場合もあります。

公式には、オプション指定と書かれてあったがどうやって指定するかわからなかったので、調べて上記の記事がヒットした。

軽く調べたら、`my.cnf`に追加しても行けるっぽい。

今回はオプション指定の方法を試しました。

<div class="code-title" data-title="sh">
```sh
root@localhost ~]#  mysqld_safe --skip-grant-tables &
[1] 3894
[root@localhost ~]# 210326 09:32:53 mysqld_safe Logging to '/var/log/mariadb/mariadb.log'.
210326 09:32:53 mysqld_safe Starting mysqld daemon with databases from /var/lib/mysql

[root@localhost ~]#  mysqld_safe --skip-grant-tables &
[2] 4088
[root@localhost ~]# 210326 09:35:08 mysqld_safe Logging to '/var/log/mariadb/mariadb.log'.
210326 09:35:09 mysqld_safe A mysqld process already exists

[2]+  Exit 1                  mysqld_safe --skip-grant-tables
```
</div>

`mysqld_safe --skip-grant-tables &`を一回実行したら、固まったのでもう一度実行した。

 `already exists`（既にある）って言われたので、「あぁ、成功してたんだ」ってなりました。

## MariaDB起動

接続完了した。

<div class="code-title" data-title="mariadb">
```mariadb
[root@localhost ~]# mysql -u root
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 1
Server version: 5.5.60-MariaDB MariaDB Server

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> use mysql
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
MariaDB [mysql]> show tables;
+---------------------------+
| Tables_in_mysql           |
+---------------------------+
| columns_priv              |
| db                        |
| event                     |
| func                      |
| general_log               |
| help_category             |
| help_keyword              |
| help_relation             |
| help_topic                |
| host                      |
| ndb_binlog_index          |
| plugin                    |
| proc                      |
| procs_priv                |
| proxies_priv              |
| servers                   |
| slow_log                  |
| tables_priv               |
| time_zone                 |
| time_zone_leap_second     |
| time_zone_name            |
| time_zone_transition      |
| time_zone_transition_type |
| user                      |
+---------------------------+
24 rows in set (0.00 sec)
```
</div>

# root password 特定（寄り道）

あとは、セーフティーモードのままrootのパスワード変更のSQLを実行するだけで問題は解決するのですが...

ここで、rootパスワードが気になった。

”調べたい”と思い、一旦`my.cnf`とか見ようと思いMariaDBを切断した。

セーフティーモードも解除しようと思い、参考にした記事通り進めようとした。

MariaDBのプロセスIDを特定してkillする手順を取る。

`ps`コマンドでプロセス確認。

`mysql`のプロセスID4040をkill

2回killコマンド実行している理由といて、`kill`したあと確認のために行った`ps`コマンドだが、`mysqld_safe`がある。

killできてないのかと思ってもう一度実行した。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# ps aux | grep mariadb
mysql     4040  0.0 12.3 980820 93756 pts/0    Sl   09:32   0:00 /usr/libexec/mysqld --basedir=/usr --datadir=/var/lib/mysql --plugin-dir=/usr/lib64/mysql/plugin --user=mysql --skip-grant-tables --log-error=/var/log/mariadb/mariadb.log --pid-file=/var/run/mariadb/mariadb.pid --socket=/var/lib/mysql/mysql.sock
root      4215  0.0  0.1 112708   976 pts/0    R+   09:43   0:00 grep --color=auto mariadb
[root@localhost ~]# kill -9 4040
[root@localhost ~]# ps
  PID TTY          TIME CMD
 3787 pts/0    00:00:00 bash
 3894 pts/0    00:00:00 mysqld_safe
 4288 pts/0    00:00:00 ps
[root@localhost ~]# kill -9 4040
-bash: kill: (4040) - No such process
```
</div>

## セーフティーモード解除されない問題

別のプロセスIDで`mysql`が実行されている。

変だと思ったので、mariadbに接続できるかを確認した。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# ps aux | grep mariadb
mysql     4263  0.2 11.4 914988 86536 pts/0    Sl   09:43   0:00 /usr/libexec/mysqld --basedir=/usr --datadir=/var/lib/mysql --plugin-dir=/usr/lib64/mysql/plugin --user=mysql --skip-grant-tables --log-error=/var/log/mariadb/mariadb.log --pid-file=/var/run/mariadb/mariadb.pid --socket=/var/lib/mysql/mysql.sock
root      4290  0.0  0.1 112708   976 pts/0    R+   09:43   0:00 grep --color=auto mariadb
[root@localhost ~]# mysql -u root -p
Enter password:
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 1
Server version: 5.5.60-MariaDB MariaDB Server

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> exit
Bye
[root@localhost ~]# mysql -u root -p
Enter password:
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 2
Server version: 5.5.60-MariaDB MariaDB Server

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> exit
Bye
```
</div>

適当なパスワードで接続可能だった。

**セーフティーモードが解除されていない。**

`ps aux | grep mariadb`コマンドで、確認しつつ`kill`してを5回ぐらい繰り返した。

`systemctl`で確認したり起動したがうまくいかず。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# systemctl start mariadb
[root@localhost ~]# systemctl status mariadb
● mariadb.service - MariaDB database server
   Loaded: loaded (/usr/lib/systemd/system/mariadb.service; enabled; vendor preset: disabled)
   Active: failed (Result: exit-code) since Fri 2021-03-26 09:45:21 JST; 1s ago
  Process: 4345 ExecStartPost=/usr/libexec/mariadb-wait-ready $MAINPID (code=exited, status=0/SUCCESS)
  Process: 4344 ExecStart=/usr/bin/mysqld_safe --basedir=/usr (code=exited, status=1/FAILURE)
  Process: 4314 ExecStartPre=/usr/libexec/mariadb-prepare-db-dir %n (code=exited, status=0/SUCCESS)
 Main PID: 4344 (code=exited, status=1/FAILURE)

Mar 26 09:45:21 localhost.localdomain systemd[1]: Starting MariaDB database server...
Mar 26 09:45:21 localhost.localdomain mariadb-prepare-db-dir[4314]: Database MariaDB is probably initialized in /var/lib/mysql already, nothing is done.
Mar 26 09:45:21 localhost.localdomain systemd[1]: Started MariaDB database server.
Mar 26 09:45:21 localhost.localdomain mysqld_safe[4344]: 210326 09:45:21 mysqld_safe Logging to '/var/log/mariadb/mariadb.log'.
Mar 26 09:45:21 localhost.localdomain mysqld_safe[4344]: 210326 09:45:21 mysqld_safe A mysqld process already exists
Mar 26 09:45:21 localhost.localdomain systemd[1]: mariadb.service: main process exited, code=exited, status=1/FAILURE
Mar 26 09:45:21 localhost.localdomain systemd[1]: Unit mariadb.service entered failed state.
Mar 26 09:45:21 localhost.localdomain systemd[1]: mariadb.service failed.
```
</div>

## セーフティーモード解除成功

複数回繰り返した結果。

mysqlの行がなくなった。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]#  ps aux | grep mysql
mysql     5035  0.0 11.7 914988 89036 pts/0    Sl   09:48   0:00 /usr/libexec/mysqld --basedir=/usr --datadir=/var/lib/mysql --plugin-dir=/usr/lib64/mysql/plugin --user=mysql --skip-grant-tables --log-error=/var/log/mariadb/mariadb.log --pid-file=/var/run/mariadb/mariadb.pid --socket=/var/lib/mysql/mysql.sock
root      5200  0.0  0.1 112708   980 pts/0    R+   10:26   0:00 grep --color=auto mysql
[root@localhost ~]# kill -9 5035
[root@localhost ~]#  ps aux | grep mysql
root      5202  0.0  0.1 112708   980 pts/0    R+   10:27   0:00 grep --color=auto mysql
```
</div>

## サービス再起動

複数プロセスが起動していたのか削除しても起動するようになっていたのか、詳しくはわかりません。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# systemctl start mariadb
[root@localhost ~]# systemctl status mariadb
● mariadb.service - MariaDB database server
   Loaded: loaded (/usr/lib/systemd/system/mariadb.service; enabled; vendor preset: disabled)
   Active: active (running) since Fri 2021-03-26 10:27:14 JST; 19s ago
  Process: 5273 ExecStartPost=/usr/libexec/mariadb-wait-ready $MAINPID (code=exited, status=0/SUCCESS)
  Process: 5242 ExecStartPre=/usr/libexec/mariadb-prepare-db-dir %n (code=exited, status=0/SUCCESS)
 Main PID: 5272 (mysqld_safe)
   CGroup: /system.slice/mariadb.service
           tq5272 /bin/sh /usr/bin/mysqld_safe --basedir=/usr
           mq5436 /usr/libexec/mysqld --basedir=/usr --datadir=/var/lib/mysql --plugin-dir=/usr/lib64/mysql/plugin --log-error=/var/log/mariadb/mariadb.log --pid-file=/var/run/mariadb/ma...

Mar 26 10:27:12 localhost.localdomain systemd[1]: Starting MariaDB database server...
Mar 26 10:27:12 localhost.localdomain mariadb-prepare-db-dir[5242]: Database MariaDB is probably initialized in /var/lib/mysql already, nothing is done.
Mar 26 10:27:12 localhost.localdomain mysqld_safe[5272]: 210326 10:27:12 mysqld_safe Logging to '/var/log/mariadb/mariadb.log'.
Mar 26 10:27:12 localhost.localdomain mysqld_safe[5272]: 210326 10:27:12 mysqld_safe Starting mysqld daemon with databases from /var/lib/mysql
Mar 26 10:27:14 localhost.localdomain systemd[1]: Started MariaDB database server.
```
</div>

# MariaDB root 初期パスワード探索の旅

とりあえずスタートラインに戻ったので、MySQLとは初期パスワードの調べる手順が違う可能性があるので調べてみた。

そしたら、MariaDBのroot初期パスワードは、「入力無し」と書いてある記事を見つけた。

そんなまさか...と思いやってみた。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# mysql -u root -p
Enter password:
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 5
Server version: 5.5.60-MariaDB MariaDB Server

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]>
```
</div>

`Enter`を押すだけなので見てもわからないと思いますが、初期パスワードが”入力なし”で合ってたみたいです。

rootでMariaDBにログインできたので、

**パスワードを変更する必要性がなかったというオチです。**

# おまけ

MySQLでは、初期パスワードが`/var/log/mysqld.log`にあるので調べてみたがそんなものはなかった。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# ls -l /var/log/
anaconda/           boot.log-20190726   cron-20190530       grubby              maillog-20190805    messages-20210326   secure-20210326     tuned/
audit/              boot.log-20190805   cron-20190726       grubby_prune_debug  maillog-20210326    qemu-ga/            spooler             wtmp
boot.log            boot.log-20210326   cron-20190805       httpd/              mariadb/            rhsm/               spooler-20190530    xferlog
boot.log-20190523   btmp                cron-20210326       lastlog             messages            secure              spooler-20190726    xferlog-20190805
boot.log-20190524   btmp-20210326       dmesg               maillog             messages-20190530   secure-20190530     spooler-20190805    xferlog-20210326
boot.log-20190529   chrony/             dmesg.old           maillog-20190530    messages-20190726   secure-20190726     spooler-20210326    yum.log
boot.log-20190530   cron                firewalld           maillog-20190726    messages-20190805   secure-20190805     tallylog            yum.log-20210326
[root@localhost ~]# ls -l /var/log/mysqld
ls: cannot access /var/log/mysqld: No such file or directory
```
</div>

mariadbのフォルダもあったので探したがそれらしい記述はなかった。

<div class="code-title" data-title="sh">
```sh
[root@localhost ~]# cat /var/log/mariadb/mariadb.log  | grep root
[root@localhost ~]# cat /var/log/mariadb/mariadb.log  | grep @
[root@localhost ~]# cat /var/log/mariadb/mariadb.log  | grep password
```
</div>

# 〆

必死でrootのパスワードを変更しようとしたが、パスワードがわかったので変更する必要がなかったという記録です。

