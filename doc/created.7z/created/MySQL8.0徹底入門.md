# 目次

[:contents]

# とある日

MySQL 徹底入門 第 4 版 MySQL 8.0 対応を読んでて、Chapter2 インストールにて Docker による環境構築を行っている例が載っていた。

Docker 使ったことないからを使ってみたい。

ってことで、MySQL 徹底入門 第 4 版 MySQL 8.0 対応のインストール手順と Docker の環境構築を参考にしながら MySQL の構築をしたいと思います。

ちなみに、MySQL 徹底入門 第 4 版 MySQL 8.0 対応は読み終わってはないですが、入門というだけあっていちから解説されていてとてもわかりやすい。

##　今回の目標

- Docker インストール

- Docker 上で MySQL8.0 インストール

- MySQL でユーザ作成し接続確認

  内容的には基礎的なことですが、今後この環境を使って MySQL 8.0 徹底入門第 4 版にある様々な機能を試していきたいと思ってます。

  MySQL8.0 の新機能とかを試してみたい。

  本書を読んでいて、新発見がたくさんあったので**知っているだけ**でなく、**できるよう**になりたい。

#　 MySQL 8.0 徹底入門第 4 版

[MySQL 8.0 徹底入門第 4 版](https://www.amazon.co.jp/MySQL%E5%BE%B9%E5%BA%95%E5%85%A5%E9%96%80-%E7%AC%AC4%E7%89%88-MySQL-8-0%E5%AF%BE%E5%BF%9C-yoku0825/dp/4798161489)

まだ、全ては読み終えてはいない。

MySQL の入門書ではなく MySQL8.0 の入門書だった。

初めの方で、MySQL の基本的内容が載っているが、後半になってくると専門的になり難易度が上がるが自分は問題なかった。

ただ、初版本は誤植が多いのでそこが少し残念だったなと思いました。

MySQL8.0 について学ぶならこの一冊だなという内容だった。

MySQL8.0 では、ROLE や空間 INDEX など、面白うそうな機能が追加されていてそれらの機能の解説もあるので、今後やってみたいと思う。

# 事前準備

## 使用する環境

- ホスト OS 　 Windows10
- 仮想環境　 Oracle VM VirtualBox 6.0.14
- ゲスト OS 　 CentOS7

VirtualBox で、CentOS7 の構築を行います。

## CentOS7 設定内容

- ユーザ作成
- sudo 権限付与
- keymap 変更
- ssh 接続

# Docker 構築

## Docker 概要

本書でも、Docker の説明がありましたが、独自で少し調べてみる。

調べてわかりやすそうな記事を見つけた。

- [Docker ハンドブック](https://shimo5.me/post/2020-09-07/)
- [Docker 入門（第一回）～ Docker とは何か、何が良いのか～](https://knowledge.sakura.ad.jp/13265/)

Docker ハンドブックに下記の VirtualBox の説明があり、なるほどと思った。

> Docker は、Linux のコンテナ技術を使ったもので、よく仮想マシンと比較されます。VirtualBox などの仮想マシンでは、ホストマシン上でハイパーバイザを利用しゲスト OS を動かし、その上でミドルウェアなどを動かします。それに対し、コンテナはホストマシンのカーネルを利用し、プロセスやユーザなどを隔離することで、あたかも別のマシンが動いているかのように動かすことができます。そのため、軽量で高速に起動、停止などが可能です。

## Docker インストール

### 1.必要なパッケージのインストール

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# yum install -y yum-utils device-mapper-persistent-data lvm2
読み込んだプラグイン:fastestmirror
Determining fastest mirrors
 * base: ftp.iij.ad.jp
 * extras: ftp.iij.ad.jp
 * updates: ftp.iij.ad.jp
base                                                     | 3.6 kB     00:00
extras                                                   | 2.9 kB     00:00
updates                                                  | 2.9 kB     00:00
(1/4): base/7/x86_64/group_gz                              | 153 kB   00:00
(2/4): extras/7/x86_64/primary_db                          | 206 kB   00:00
(3/4): updates/7/x86_64/primary_db                         | 4.5 MB   00:00
(4/4): base/7/x86_64/primary_db                            | 6.1 MB   00:00
依存性の解決をしています
--> トランザクションの確認を実行しています。
---> パッケージ device-mapper-persistent-data.x86_64 0:0.7.3-3.el7 を 更新
---> パッケージ device-mapper-persistent-data.x86_64 0:0.8.5-2.el7 を アップデート
---> パッケージ lvm2.x86_64 7:2.02.180-8.el7 を 更新
---> パッケージ lvm2.x86_64 7:2.02.186-7.el7_8.2 を アップデート
--> 依存性の処理をしています: lvm2-libs = 7:2.02.186-7.el7_8.2 のパッケージ: 7:lvm2-2.02.186-7.el7_8.2.x86_64
---> パッケージ yum-utils.noarch 0:1.1.31-54.el7_8 を インストール
--> 依存性の処理をしています: python-kitchen のパッケージ: yum-utils-1.1.31-54.el7_8.noarch
--> 依存性の処理をしています: libxml2-python のパッケージ: yum-utils-1.1.31-54.el7_8.noarch
--> トランザクションの確認を実行しています。
---> パッケージ libxml2-python.x86_64 0:2.9.1-6.el7.4 を インストール
--> 依存性の処理をしています: libxml2 = 2.9.1-6.el7.4 のパッケージ: libxml2-python-2.9.1-6.el7.4.x86_64
---> パッケージ lvm2-libs.x86_64 7:2.02.180-8.el7 を 更新
---> パッケージ lvm2-libs.x86_64 7:2.02.186-7.el7_8.2 を アップデート
--> 依存性の処理をしています: device-mapper-event = 7:1.02.164-7.el7_8.2 のパッ ケージ: 7:lvm2-libs-2.02.186-7.el7_8.2.x86_64
---> パッケージ python-kitchen.noarch 0:1.1.1-5.el7 を インストール
--> 依存性の処理をしています: python-chardet のパッケージ: python-kitchen-1.1.1-5.el7.noarch
--> トランザクションの確認を実行しています。
---> パッケージ device-mapper-event.x86_64 7:1.02.149-8.el7 を 更新
---> パッケージ device-mapper-event.x86_64 7:1.02.164-7.el7_8.2 を アップデート
--> 依存性の処理をしています: device-mapper-event-libs = 7:1.02.164-7.el7_8.2 のパッケージ: 7:device-mapper-event-1.02.164-7.el7_8.2.x86_64
--> 依存性の処理をしています: device-mapper = 7:1.02.164-7.el7_8.2 のパッケージ: 7:device-mapper-event-1.02.164-7.el7_8.2.x86_64
---> パッケージ libxml2.x86_64 0:2.9.1-6.el7_2.3 を 更新
---> パッケージ libxml2.x86_64 0:2.9.1-6.el7.4 を アップデート
---> パッケージ python-chardet.noarch 0:2.2.1-3.el7 を インストール
--> トランザクションの確認を実行しています。
---> パッケージ device-mapper.x86_64 7:1.02.149-8.el7 を 更新
--> 依存性の処理をしています: device-mapper = 7:1.02.149-8.el7 のパッケージ: 7:device-mapper-libs-1.02.149-8.el7.x86_64
---> パッケージ device-mapper.x86_64 7:1.02.164-7.el7_8.2 を アップデート
---> パッケージ device-mapper-event-libs.x86_64 7:1.02.149-8.el7 を 更新
---> パッケージ device-mapper-event-libs.x86_64 7:1.02.164-7.el7_8.2 を アップデート
--> トランザクションの確認を実行しています。
---> パッケージ device-mapper-libs.x86_64 7:1.02.149-8.el7 を 更新
---> パッケージ device-mapper-libs.x86_64 7:1.02.164-7.el7_8.2 を アップデート
--> 依存性解決を終了しました。

依存性を解決しました

================================================================================
 Package                        アーキテクチャー
                                        バージョン               リポジトリー
                                                                           容量
================================================================================
インストール中:
 yum-utils                      noarch  1.1.31-54.el7_8          updates  122 k
更新します:
 device-mapper-persistent-data  x86_64  0.8.5-2.el7              base     422 k
 lvm2                           x86_64  7:2.02.186-7.el7_8.2     updates  1.3 M
依存性関連でのインストールをします:
 libxml2-python                 x86_64  2.9.1-6.el7.4            base     247 k
 python-chardet                 noarch  2.2.1-3.el7              base     227 k
 python-kitchen                 noarch  1.1.1-5.el7              base     267 k
依存性関連での更新をします:
 device-mapper                  x86_64  7:1.02.164-7.el7_8.2     updates  295 k
 device-mapper-event            x86_64  7:1.02.164-7.el7_8.2     updates  191 k
 device-mapper-event-libs       x86_64  7:1.02.164-7.el7_8.2     updates  190 k
 device-mapper-libs             x86_64  7:1.02.164-7.el7_8.2     updates  324 k
 libxml2                        x86_64  2.9.1-6.el7.4            base     668 k
 lvm2-libs                      x86_64  7:2.02.186-7.el7_8.2     updates  1.1 M

トランザクションの要約
================================================================================
インストール  1 パッケージ (+3 個の依存関係のパッケージ)
更新          2 パッケージ (+6 個の依存関係のパッケージ)

総ダウンロード容量: 5.3 M
Downloading packages:
Delta RPMs disabled because /usr/bin/applydeltarpm not installed.
警告: /var/cache/yum/x86_64/7/updates/packages/device-mapper-event-1.02.164-7.el7_8.2.x86_64.rpm: ヘッダー V3 RSA/SHA256 Signature、鍵 ID f4a80eb5: NOKEY
device-mapper-event-1.02.164-7.el7_8.2.x86_64.rpm の公開鍵がインストールされていません
(1/12): device-mapper-event-1.02.164-7.el7_8.2.x86_64.rpm  | 191 kB   00:00
(2/12): device-mapper-libs-1.02.164-7.el7_8.2.x86_64.rpm   | 324 kB   00:00
(3/12): device-mapper-event-libs-1.02.164-7.el7_8.2.x86_64 | 190 kB   00:00
(4/12): device-mapper-1.02.164-7.el7_8.2.x86_64.rpm        | 295 kB   00:00
device-mapper-persistent-data-0.8.5-2.el7.x86_64.rpm の公開鍵がインストールされ ていません
(5/12): device-mapper-persistent-data-0.8.5-2.el7.x86_64.r | 422 kB   00:00
(6/12): libxml2-2.9.1-6.el7.4.x86_64.rpm                   | 668 kB   00:00
(7/12): libxml2-python-2.9.1-6.el7.4.x86_64.rpm            | 247 kB   00:00
(8/12): python-chardet-2.2.1-3.el7.noarch.rpm              | 227 kB   00:00
(9/12): yum-utils-1.1.31-54.el7_8.noarch.rpm               | 122 kB   00:00
(10/12): lvm2-libs-2.02.186-7.el7_8.2.x86_64.rpm           | 1.1 MB   00:00
(11/12): python-kitchen-1.1.1-5.el7.noarch.rpm             | 267 kB   00:00
(12/12): lvm2-2.02.186-7.el7_8.2.x86_64.rpm                | 1.3 MB   00:00
--------------------------------------------------------------------------------
合計                                               4.6 MB/s | 5.3 MB  00:01
file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7 から鍵を取得中です。
Importing GPG key 0xF4A80EB5:
 Userid     : "CentOS-7 Key (CentOS 7 Official Signing Key) <security@centos.org>"
 Fingerprint: 6341 ab27 53d7 8a78 a7c2 7bb1 24c6 a8a7 f4a8 0eb5
 Package    : centos-release-7-6.1810.2.el7.centos.x86_64 (@anaconda)
 From       : /etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
  更新します              : 7:device-mapper-libs-1.02.164-7.el7_8.2.x86    1/20
  更新します              : 7:device-mapper-1.02.164-7.el7_8.2.x86_64      2/20
  更新します              : 7:device-mapper-event-libs-1.02.164-7.el7_8    3/20
  更新します              : 7:device-mapper-event-1.02.164-7.el7_8.2.x8    4/20
  更新します              : 7:lvm2-libs-2.02.186-7.el7_8.2.x86_64          5/20
  インストール中          : python-chardet-2.2.1-3.el7.noarch              6/20
  インストール中          : python-kitchen-1.1.1-5.el7.noarch              7/20
  更新します              : libxml2-2.9.1-6.el7.4.x86_64                   8/20
  インストール中          : libxml2-python-2.9.1-6.el7.4.x86_64            9/20
  更新します              : device-mapper-persistent-data-0.8.5-2.el7.x   10/20
  更新します              : 7:lvm2-2.02.186-7.el7_8.2.x86_64              11/20
  インストール中          : yum-utils-1.1.31-54.el7_8.noarch              12/20
  整理中                  : 7:lvm2-2.02.180-8.el7.x86_64                  13/20
  整理中                  : 7:lvm2-libs-2.02.180-8.el7.x86_64             14/20
  整理中                  : 7:device-mapper-event-1.02.149-8.el7.x86_64   15/20
  整理中                  : 7:device-mapper-event-libs-1.02.149-8.el7.x   16/20
  整理中                  : 7:device-mapper-1.02.149-8.el7.x86_64         17/20
  整理中                  : 7:device-mapper-libs-1.02.149-8.el7.x86_64    18/20
  整理中                  : device-mapper-persistent-data-0.7.3-3.el7.x   19/20
  整理中                  : libxml2-2.9.1-6.el7_2.3.x86_64                20/20
  検証中                  : 7:device-mapper-event-1.02.164-7.el7_8.2.x8    1/20
  検証中                  : device-mapper-persistent-data-0.8.5-2.el7.x    2/20
  検証中                  : 7:device-mapper-1.02.164-7.el7_8.2.x86_64      3/20
  検証中                  : 7:lvm2-libs-2.02.186-7.el7_8.2.x86_64          4/20
  検証中                  : python-kitchen-1.1.1-5.el7.noarch              5/20
  検証中                  : 7:lvm2-2.02.186-7.el7_8.2.x86_64               6/20
  検証中                  : 7:device-mapper-libs-1.02.164-7.el7_8.2.x86    7/20
  検証中                  : libxml2-python-2.9.1-6.el7.4.x86_64            8/20
  検証中                  : 7:device-mapper-event-libs-1.02.164-7.el7_8    9/20
  検証中                  : libxml2-2.9.1-6.el7.4.x86_64                  10/20
  検証中                  : yum-utils-1.1.31-54.el7_8.noarch              11/20
  検証中                  : python-chardet-2.2.1-3.el7.noarch             12/20
  検証中                  : device-mapper-persistent-data-0.7.3-3.el7.x   13/20
  検証中                  : 7:lvm2-2.02.180-8.el7.x86_64                  14/20
  検証中                  : 7:device-mapper-event-1.02.149-8.el7.x86_64   15/20
  検証中                  : 7:lvm2-libs-2.02.180-8.el7.x86_64             16/20
  検証中                  : libxml2-2.9.1-6.el7_2.3.x86_64                17/20
  検証中                  : 7:device-mapper-1.02.149-8.el7.x86_64         18/20
  検証中                  : 7:device-mapper-libs-1.02.149-8.el7.x86_64    19/20
  検証中                  : 7:device-mapper-event-libs-1.02.149-8.el7.x   20/20

インストール:
  yum-utils.noarch 0:1.1.31-54.el7_8

依存性関連をインストールしました:
  libxml2-python.x86_64 0:2.9.1-6.el7.4   python-chardet.noarch 0:2.2.1-3.el7
  python-kitchen.noarch 0:1.1.1-5.el7

更新:
  device-mapper-persistent-data.x86_64 0:0.8.5-2.el7
  lvm2.x86_64 7:2.02.186-7.el7_8.2

依存性を更新しました:
  device-mapper.x86_64 7:1.02.164-7.el7_8.2
  device-mapper-event.x86_64 7:1.02.164-7.el7_8.2
  device-mapper-event-libs.x86_64 7:1.02.164-7.el7_8.2
  device-mapper-libs.x86_64 7:1.02.164-7.el7_8.2
  libxml2.x86_64 0:2.9.1-6.el7.4
  lvm2-libs.x86_64 7:2.02.186-7.el7_8.2

完了しました!

```
</div>

### 2.Docker(安定版)のリポジトリを追加

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# yum-config-manager --add-repo https://download.docker.com/li
nux/centos/docker-ce.repo
読み込んだプラグイン:fastestmirror
adding repo from: https://download.docker.com/linux/centos/docker-ce.repo
grabbing file https://download.docker.com/linux/centos/docker-ce.repo to /etc/yum.repos.d/docker-ce.repo
repo saved to /etc/yum.repos.d/docker-ce.repo

```
</div>

### 3.Docker CE のインストール

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# yum install docker-ce docker-ce-cli containerd.io
読み込んだプラグイン:fastestmirror
Loading mirror speeds from cached hostfile
 * base: ftp.iij.ad.jp
 * extras: ftp.iij.ad.jp
 * updates: ftp.iij.ad.jp
docker-ce-stable                                         | 3.5 kB     00:00
(1/2): docker-ce-stable/7/x86_64/updateinfo                |   55 B   00:00
(2/2): docker-ce-stable/7/x86_64/primary_db                |  46 kB   00:00
依存性の解決をしています
--> トランザクションの確認を実行しています。
---> パッケージ containerd.io.x86_64 0:1.3.7-3.1.el7 を インストール
--> 依存性の処理をしています: container-selinux >= 2:2.74 のパッケージ: containerd.io-1.3.7-3.1.el7.x86_64
---> パッケージ docker-ce.x86_64 3:19.03.13-3.el7 を インストール
--> 依存性の処理をしています: libcgroup のパッケージ: 3:docker-ce-19.03.13-3.el7.x86_64
---> パッケージ docker-ce-cli.x86_64 1:19.03.13-3.el7 を インストール
--> トランザクションの確認を実行しています。
---> パッケージ container-selinux.noarch 2:2.119.2-1.911c772.el7_8 を インストール
--> 依存性の処理をしています: policycoreutils-python のパッケージ: 2:container-selinux-2.119.2-1.911c772.el7_8.noarch
---> パッケージ libcgroup.x86_64 0:0.41-21.el7 を インストール
--> トランザクションの確認を実行しています。
---> パッケージ policycoreutils-python.x86_64 0:2.5-34.el7 を インストール
--> 依存性の処理をしています: policycoreutils = 2.5-34.el7 のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: setools-libs >= 3.3.8-4 のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: libsemanage-python >= 2.5-14 のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: audit-libs-python >= 2.1.3-4 のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: python-IPy のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: libqpol.so.1(VERS_1.4)(64bit) のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: libqpol.so.1(VERS_1.2)(64bit) のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: libapol.so.4(VERS_4.0)(64bit) のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: checkpolicy のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: libqpol.so.1()(64bit) のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> 依存性の処理をしています: libapol.so.4()(64bit) のパッケージ: policycoreutils-python-2.5-34.el7.x86_64
--> トランザクションの確認を実行しています。
---> パッケージ audit-libs-python.x86_64 0:2.8.5-4.el7 を インストール
--> 依存性の処理をしています: audit-libs(x86-64) = 2.8.5-4.el7 のパッケージ: audit-libs-python-2.8.5-4.el7.x86_64
---> パッケージ checkpolicy.x86_64 0:2.5-8.el7 を インストール
---> パッケージ libsemanage-python.x86_64 0:2.5-14.el7 を インストール
---> パッケージ policycoreutils.x86_64 0:2.5-29.el7 を 更新
---> パッケージ policycoreutils.x86_64 0:2.5-34.el7 を アップデート
---> パッケージ python-IPy.noarch 0:0.75-6.el7 を インストール
---> パッケージ setools-libs.x86_64 0:3.3.8-4.el7 を インストール
--> トランザクションの確認を実行しています。
---> パッケージ audit-libs.x86_64 0:2.8.4-4.el7 を 更新
--> 依存性の処理をしています: audit-libs(x86-64) = 2.8.4-4.el7 のパッケージ: audit-2.8.4-4.el7.x86_64
---> パッケージ audit-libs.x86_64 0:2.8.5-4.el7 を アップデート
--> トランザクションの確認を実行しています。
---> パッケージ audit.x86_64 0:2.8.4-4.el7 を 更新
---> パッケージ audit.x86_64 0:2.8.5-4.el7 を アップデート
--> 依存性解決を終了しました。

依存性を解決しました

================================================================================
 Package                アーキテクチャー
                               バージョン                リポジトリー      容量
================================================================================
インストール中:
 containerd.io          x86_64 1.3.7-3.1.el7             docker-ce-stable  29 M
 docker-ce              x86_64 3:19.03.13-3.el7          docker-ce-stable  24 M
 docker-ce-cli          x86_64 1:19.03.13-3.el7          docker-ce-stable  38 M
依存性関連でのインストールをします:
 audit-libs-python      x86_64 2.8.5-4.el7               base              76 k
 checkpolicy            x86_64 2.5-8.el7                 base             295 k
 container-selinux      noarch 2:2.119.2-1.911c772.el7_8 extras            40 k
 libcgroup              x86_64 0.41-21.el7               base              66 k
 libsemanage-python     x86_64 2.5-14.el7                base             113 k
 policycoreutils-python x86_64 2.5-34.el7                base             457 k
 python-IPy             noarch 0.75-6.el7                base              32 k
 setools-libs           x86_64 3.3.8-4.el7               base             620 k
依存性関連での更新をします:
 audit                  x86_64 2.8.5-4.el7               base             256 k
 audit-libs             x86_64 2.8.5-4.el7               base             102 k
 policycoreutils        x86_64 2.5-34.el7                base             917 k

トランザクションの要約
================================================================================
インストール  3 パッケージ (+8 個の依存関係のパッケージ)
更新                       ( 3 個の依存関係のパッケージ)

総ダウンロード容量: 94 M
Is this ok [y/d/N]: y
Downloading packages:
Delta RPMs disabled because /usr/bin/applydeltarpm not installed.
(1/14): audit-libs-2.8.5-4.el7.x86_64.rpm                  | 102 kB   00:00
(2/14): audit-libs-python-2.8.5-4.el7.x86_64.rpm           |  76 kB   00:00
(3/14): container-selinux-2.119.2-1.911c772.el7_8.noarch.r |  40 kB   00:00
(4/14): checkpolicy-2.5-8.el7.x86_64.rpm                   | 295 kB   00:00
(5/14): audit-2.8.5-4.el7.x86_64.rpm                       | 256 kB   00:00
warning: /var/cache/yum/x86_64/7/docker-ce-stable/packages/docker-ce-19.03.13-3.el7.x86_64.rpm: Header V4 RSA/SHA512 Signature, key ID 621e9f35: NOKEY
docker-ce-19.03.13-3.el7.x86_64.rpm の公開鍵がインストールされていません
(6/14): docker-ce-19.03.13-3.el7.x86_64.rpm                |  24 MB   00:02
(7/14): libsemanage-python-2.5-14.el7.x86_64.rpm           | 113 kB   00:00
(8/14): libcgroup-0.41-21.el7.x86_64.rpm                   |  66 kB   00:00
(9/14): policycoreutils-python-2.5-34.el7.x86_64.rpm       | 457 kB   00:00
(10/14): python-IPy-0.75-6.el7.noarch.rpm                  |  32 kB   00:00
(11/14): setools-libs-3.3.8-4.el7.x86_64.rpm               | 620 kB   00:00
(12/14): policycoreutils-2.5-34.el7.x86_64.rpm             | 917 kB   00:00
(13/14): containerd.io-1.3.7-3.1.el7.x86_64.rpm            |  29 MB   00:03
(14/14): docker-ce-cli-19.03.13-3.el7.x86_64.rpm           |  38 MB   00:02
--------------------------------------------------------------------------------
合計                                                18 MB/s |  94 MB  00:05
https://download.docker.com/linux/centos/gpg から鍵を取得中です。
Importing GPG key 0x621E9F35:
 Userid     : "Docker Release (CE rpm) <docker@docker.com>"
 Fingerprint: 060a 61c5 1b55 8a7f 742b 77aa c52f eb6b 621e 9f35
 From       : https://download.docker.com/linux/centos/gpg
上記の処理を行います。よろしいでしょうか？ [y/N]y
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
  更新します              : audit-libs-2.8.5-4.el7.x86_64                  1/17
  更新します              : policycoreutils-2.5-34.el7.x86_64              2/17
  インストール中          : libcgroup-0.41-21.el7.x86_64                   3/17
  インストール中          : audit-libs-python-2.8.5-4.el7.x86_64           4/17
  インストール中          : setools-libs-3.3.8-4.el7.x86_64                5/17
  インストール中          : libsemanage-python-2.5-14.el7.x86_64           6/17
  インストール中          : checkpolicy-2.5-8.el7.x86_64                   7/17
  インストール中          : python-IPy-0.75-6.el7.noarch                   8/17
  インストール中          : policycoreutils-python-2.5-34.el7.x86_64       9/17
  インストール中          : 2:container-selinux-2.119.2-1.911c772.el7_8   10/17
  インストール中          : containerd.io-1.3.7-3.1.el7.x86_64            11/17
  インストール中          : 1:docker-ce-cli-19.03.13-3.el7.x86_64         12/17
  インストール中          : 3:docker-ce-19.03.13-3.el7.x86_64             13/17
  更新します              : audit-2.8.5-4.el7.x86_64                      14/17
  整理中                  : policycoreutils-2.5-29.el7.x86_64             15/17
  整理中                  : audit-2.8.4-4.el7.x86_64                      16/17
  整理中                  : audit-libs-2.8.4-4.el7.x86_64                 17/17
  検証中                  : audit-libs-2.8.5-4.el7.x86_64                  1/17
  検証中                  : audit-2.8.5-4.el7.x86_64                       2/17
  検証中                  : containerd.io-1.3.7-3.1.el7.x86_64             3/17
  検証中                  : policycoreutils-2.5-34.el7.x86_64              4/17
  検証中                  : 3:docker-ce-19.03.13-3.el7.x86_64              5/17
  検証中                  : 1:docker-ce-cli-19.03.13-3.el7.x86_64          6/17
  検証中                  : 2:container-selinux-2.119.2-1.911c772.el7_8    7/17
  検証中                  : python-IPy-0.75-6.el7.noarch                   8/17
  検証中                  : checkpolicy-2.5-8.el7.x86_64                   9/17
  検証中                  : policycoreutils-python-2.5-34.el7.x86_64      10/17
  検証中                  : libsemanage-python-2.5-14.el7.x86_64          11/17
  検証中                  : setools-libs-3.3.8-4.el7.x86_64               12/17
  検証中                  : audit-libs-python-2.8.5-4.el7.x86_64          13/17
  検証中                  : libcgroup-0.41-21.el7.x86_64                  14/17
  検証中                  : policycoreutils-2.5-29.el7.x86_64             15/17
  検証中                  : audit-libs-2.8.4-4.el7.x86_64                 16/17
  検証中                  : audit-2.8.4-4.el7.x86_64                      17/17

インストール:
  containerd.io.x86_64 0:1.3.7-3.1.el7     docker-ce.x86_64 3:19.03.13-3.el7
  docker-ce-cli.x86_64 1:19.03.13-3.el7

依存性関連をインストールしました:
  audit-libs-python.x86_64 0:2.8.5-4.el7
  checkpolicy.x86_64 0:2.5-8.el7
  container-selinux.noarch 2:2.119.2-1.911c772.el7_8
  libcgroup.x86_64 0:0.41-21.el7
  libsemanage-python.x86_64 0:2.5-14.el7
  policycoreutils-python.x86_64 0:2.5-34.el7
  python-IPy.noarch 0:0.75-6.el7
  setools-libs.x86_64 0:3.3.8-4.el7

依存性を更新しました:
  audit.x86_64 0:2.8.5-4.el7               audit-libs.x86_64 0:2.8.5-4.el7
  policycoreutils.x86_64 0:2.5-34.el7

完了しました!

```
</div>

### 4.Docker サービス起動と有効化

本書ではなかったですが、status で起動確認。

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# systemctl start docker
[root@localhost ~]# systemctl status docker
● docker.service - Docker Application Container Engine
   Loaded: loaded (/usr/lib/systemd/system/docker.service; disabled; vendor preset: disabled)
   Active: active (running) since 水 2020-09-23 08:45:23 JST; 5s ago
     Docs: https://docs.docker.com
 Main PID: 21748 (dockerd)
    Tasks: 8
   Memory: 39.9M
   CGroup: /system.slice/docker.service
           mq21748 /usr/bin/dockerd -H fd:// --containerd=/run/containerd/con...

 9月 23 08:45:22 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:22 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:22 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:22 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:23 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:23 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:23 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:23 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
 9月 23 08:45:23 localhost.localdomain systemd[1]: Started Docker Applicatio...
 9月 23 08:45:23 localhost.localdomain dockerd[21748]: time="2020-09-23T08:4...
Hint: Some lines were ellipsized, use -l to show in full.
[root@localhost ~]# systemctl enable docker
Created symlink from /etc/systemd/system/multi-user.target.wants/docker.service to /usr/lib/systemd/system/docker.service.


```
</div>

さくさくと、インストールから起動までできました。

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker run hello-world
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
0e03bdcc26d7: Pull complete
Digest: sha256:4cf9c47f86df71d48364001ede3a4fcd85ae80ce02ebad74156906caff5378bc
Status: Downloaded newer image for hello-world:latest

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/

```
</div>

問題なく、Hello from Docker!と表示された。

# MySQL 構築

## 1.Docker イメージダウンロード

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker search mysql
NAME                              DESCRIPTION                                                                                                                                                  STARS               OFFICIAL            AUTOMATED
mysql                             MySQL is a widely used, open-source relation…                                                                                                                10011               [OK]
mariadb                           MariaDB is a community-developed fork of MyS…                                                                                                                3665                [OK]
mysql/mysql-server                Optimized MySQL Server Docker images. Create…                                                                                                                733                                     [OK]
percona                           Percona Server is a fork of the MySQL relati…                                                                                                                512                 [OK]
centos/mysql-57-centos7           MySQL 5.7 SQL database server                                                                                                                                83
mysql/mysql-cluster               Experimental MySQL Cluster Docker images. Cr…                                                                                                                76
centurylink/mysql                 Image containing mysql. Optimized to be link…                                                                                                                61                                      [OK]
bitnami/mysql                     Bitnami MySQL Docker Image                                                                                                                                   45                                      [OK]
deitch/mysql-backup               REPLACED! Please use http://hub.docker.com/r…                                                                                                                41                                      [OK]
tutum/mysql                       Base docker image to run a MySQL database se…                                                                                                                35
prom/mysqld-exporter                                                                                                                                                                           31                                      [OK]
schickling/mysql-backup-s3        Backup MySQL to S3 (supports periodic backup…                                                                                                                30                                      [OK]
databack/mysql-backup             Back up mysql databases to... anywhere!                                                                                                                      30
linuxserver/mysql                 A Mysql container, brought to you by LinuxSe…                                                                                                                26
centos/mysql-56-centos7           MySQL 5.6 SQL database server                                                                                                                                20
circleci/mysql                    MySQL is a widely used, open-source relation…                                                                                                                19
mysql/mysql-router                MySQL Router provides transparent routing be…                                                                                                                16
arey/mysql-client                 Run a MySQL client from a docker container                                                                                                                   15                                      [OK]
fradelg/mysql-cron-backup         MySQL/MariaDB database backup using cron tas…                                                                                                                8                                       [OK]
yloeffler/mysql-backup            This image runs mysqldump to backup data usi…                                                                                                                7                                       [OK]
openshift/mysql-55-centos7        DEPRECATED: A Centos7 based MySQL v5.5 image…                                                                                                                6
devilbox/mysql                    Retagged MySQL, MariaDB and PerconaDB offici…                                                                                                                3
ansibleplaybookbundle/mysql-apb   An APB which deploys RHSCL MySQL                                                                                                                             2                                       [OK]
jelastic/mysql                    An image of the MySQL database server mainta…                                                                                                                1
widdpim/mysql-client              Dockerized MySQL Client (5.7) including Curl…
[root@localhost ~]# docker pull mysql/mysql-server
Using default tag: latest
latest: Pulling from mysql/mysql-server
e945e9180309: Pull complete
c854b862275e: Pull complete
331a4f2ecf4b: Pull complete
d92ed785684c: Pull complete
Digest: sha256:342d3eefe147620bafd0d276491e11c8ed29e4bb712612cb955815b3aa910a19
Status: Downloaded newer image for mysql/mysql-server:latest
docker.io/mysql/mysql-server:latest
[root@localhost ~]# docker images
REPOSITORY           TAG                 IMAGE ID            CREATED                                                                                                                          SIZE
mysql/mysql-server   latest              8a3a24ad33be        2 months ago                                                                                                                     366MB
hello-world          latest              bf756fb1ae65        8 months ago
```
</div>

## 2.Docker イメージをコンテナ化起動

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker run --name=mysql1 -d mysql/mysql-server
d2276cbb215a8388c69ee03cfefa54f3b67179abf0db1299de62b04ace83917b
[root@localhost ~]# docker ps
CONTAINER ID        IMAGE                COMMAND                  CREATED                                                                                                                          STATUS                             PORTS                 NAMES
d2276cbb215a        mysql/mysql-server   "/entrypoint.sh mysq…"   13 seconds ag                                                                                                             o      Up 11 seconds (health: starting)   3306/tcp, 33060/tcp   mysql1
[root@localhost ~]#
[root@localhost ~]# docker ps
CONTAINER ID        IMAGE                COMMAND                  CREATED             STATUS                    PORTS                 NAMES
d2276cbb215a        mysql/mysql-server   "/entrypoint.sh mysq…"   32 seconds ago      Up 30 seconds (healthy)   3306/tcp, 33060/tcp   mysql1
[root@localhost ~]# docker logs mysql1
[Entrypoint] MySQL Docker Image 8.0.21-1.1.17
[Entrypoint] No password option specified for new database.
[Entrypoint]   A random onetime password will be generated.
[Entrypoint] Initializing database
2020-09-23T00:00:23.617902Z 0 [System] [MY-013169] [Server] /usr/sbin/mysqld (mysqld 8.0.21) initializing of server in progress as process 20
2020-09-23T00:00:23.627286Z 1 [System] [MY-013576] [InnoDB] InnoDB initialization has started.
2020-09-23T00:00:25.423526Z 1 [System] [MY-013577] [InnoDB] InnoDB initialization has ended.
2020-09-23T00:00:27.945939Z 6 [Warning] [MY-010453] [Server] root@localhost is created with an empty password ! Please consider switching off the --initialize-insecure option.
[Entrypoint] Database initialized
2020-09-23T00:00:34.097855Z 0 [System] [MY-010116] [Server] /usr/sbin/mysqld (mysqld 8.0.21) starting as process 65
2020-09-23T00:00:34.123691Z 1 [System] [MY-013576] [InnoDB] InnoDB initialization has started.
2020-09-23T00:00:34.789110Z 1 [System] [MY-013577] [InnoDB] InnoDB initialization has ended.
2020-09-23T00:00:34.966488Z 0 [System] [MY-011323] [Server] X Plugin ready for connections. Socket: /var/run/mysqld/mysqlx.sock
2020-09-23T00:00:35.363690Z 0 [Warning] [MY-010068] [Server] CA certificate ca.pem is self signed.
2020-09-23T00:00:35.364002Z 0 [System] [MY-013602] [Server] Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.
2020-09-23T00:00:35.393419Z 0 [System] [MY-010931] [Server] /usr/sbin/mysqld: ready for connections. Version: '8.0.21'  socket: '/var/lib/mysql/mysql.sock'  port: 0  MySQL Community Server - GPL.
Warning: Unable to load '/usr/share/zoneinfo/iso3166.tab' as time zone. Skipping it.
Warning: Unable to load '/usr/share/zoneinfo/leapseconds' as time zone. Skipping it.
Warning: Unable to load '/usr/share/zoneinfo/tzdata.zi' as time zone. Skipping it.
Warning: Unable to load '/usr/share/zoneinfo/zone.tab' as time zone. Skipping it.
Warning: Unable to load '/usr/share/zoneinfo/zone1970.tab' as time zone. Skipping it.
[Entrypoint] GENERATED ROOT PASSWORD: N4lkoh]EHvys3JmASyst@s4nkul

[Entrypoint] ignoring /docker-entrypoint-initdb.d/*

2020-09-23T00:00:38.069579Z 10 [System] [MY-013172] [Server] Received SHUTDOWN from user root. Shutting down mysqld (Version: 8.0.21).
2020-09-23T00:00:41.585394Z 0 [System] [MY-010910] [Server] /usr/sbin/mysqld: Shutdown complete (mysqld 8.0.21)  MySQL Community Server - GPL.
[Entrypoint] Server shut down
[Entrypoint] Setting root user as expired. Password will need to be changed before database can be used.

[Entrypoint] MySQL init process done. Ready for start up.

[Entrypoint] Starting MySQL 8.0.21-1.1.17
2020-09-23T00:00:43.009428Z 0 [System] [MY-010116] [Server] /usr/sbin/mysqld (mysqld 8.0.21) starting as process 128
2020-09-23T00:00:43.029497Z 1 [System] [MY-013576] [InnoDB] InnoDB initialization has started.
2020-09-23T00:00:43.632638Z 1 [System] [MY-013577] [InnoDB] InnoDB initialization has ended.
2020-09-23T00:00:43.798631Z 0 [System] [MY-011323] [Server] X Plugin ready for connections. Bind-address: '::' port: 33060, socket: /var/run/mysqld/mysqlx.sock
2020-09-23T00:00:43.964036Z 0 [Warning] [MY-010068] [Server] CA certificate ca.pem is self signed.
2020-09-23T00:00:43.964297Z 0 [System] [MY-013602] [Server] Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.
2020-09-23T00:00:43.997631Z 0 [System] [MY-010931] [Server] /usr/sbin/mysqld: ready for connections. Version: '8.0.21'  socket: '/var/lib/mysql/mysql.sock'  port: 3306  MySQL Community Server - GPL.

```
</div>

## 3.MySQL サーバにコンテナ内部から接続

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker logs mysql1 2>&1 |grep GENERATED
[Entrypoint] GENERATED ROOT PASSWORD: N4lkoh]EHvys3JmASyst@s4nkul
[root@localhost ~]# docker exec -it mysql1 mysql -u root -p
Enter password:
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 18
Server version: 8.0.21

Copyright (c) 2000, 2020, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.
```
</div>

### 道草を食う

本書に記載されていたが、MySQL の初回起動時に、root だとできることに制限がある。

<div class="code-title" data-title="mysql">
```mysql
mysql> show databases;
ERROR 1820 (HY000): You must reset your password using ALTER USER statement before executing this statement.
```
</div>

これは、知らなかった。

### root パスワード変更

Policy を変更していないので、パスワード条件が厳しいですが。

<div class="code-title" data-title="mysql">
```mysql
mysql> alter user 'root'@'localhost' identified by 'Dockermysql1';
Query OK, 0 rows affected (0.11 sec)
```
</div>

## 4.起動中のコンテナログイン

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker exec -it mysql1 bach
OCI runtime exec failed: exec failed: container_linux.go:349: starting container process caused "exec: \"bach\": executable file not found in $PATH": unknown
```
</div>

### エラーの原因

普通にググってみた。

[エラーの原因](https://mebee.info/2020/03/26/post-8053/)

書いてある通り、sh にして実行してみた。

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker exec -it mysql1 sh
sh-4.2#
```
</div>

接続完了。

同じ CentOS7 なのに本書通りには行かなかった。

ただ、問題ないのでいいかなって。

### SQL 打てると思っていた

上記のコマンドで、MySQL に接続できたと思った。

表示違うけどいけたのかなと思い show databases を実行した。

<div class="code-title" data-title="sh">
```sh
sh-4.2# show databases;
sh: show: command not found
```
</div>

怒られた。

あれ。

あ、ここから MySQL に接続するのか。

<div class="code-title" data-title="MySQL">
```MySQL
sh-4.2# mysql -u root -p
Enter password:
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 12
Server version: 8.0.21 MySQL Community Server - GPL

Copyright (c) 2000, 2020, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
4 rows in set (0.01 sec)

mysql>

##
```
</div>

できた。

おちょこちょいだった。

## 5.コンテナの停止

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker stop mysql1
mysql1
[root@localhost ~]# docker ps -a
CONTAINER ID        IMAGE                COMMAND                  CREATED             STATUS                       PORTS               NAMES
d2276cbb215a        mysql/mysql-server   "/entrypoint.sh mysq…"   8 minutes ago       Exited (137) 8 seconds ago                       mysql1
613ec9f60d12        hello-world          "/hello"                 22 minutes ago      Exited (0) 22 minutes ago                        busy_engelbart
```
</div>

最後に、コンテナ停止を実行した。

プロセスも問題ない。

ただ、今後使うので start する。

<div class="code-title" data-title="shell">
```shell
[root@localhost ~]# docker start mysql1
mysql1
```
</div>

# 〆

本書通り進んだが、サクサクと進めた。

今後も Docker を利用してアプリケーションを開発したいなと思った。

Docker の入門としてはとてもためになった。

Docker 自体も使いやすかったし。

面白かった。

MySQL 徹底入門 第 4 版 は、現在読み進めているがとてもおすすめな書籍だ。
