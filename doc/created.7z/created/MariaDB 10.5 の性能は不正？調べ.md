# 目次
[:contents]

# とある日

ツイッターでとある記事を見た。

[**MariaDB 10.5 の性能は不正？**](http://buildup-db.blogspot.com/2021/03/mariadb-105.html)

読んでみたけど、今の自分ではあまり理解できなかったので理解できるように単語を調べてみたりする。

見てない方はぜひご覧ください。

下記の6つの単語を中心に調べてみる。

- **fsync()**
- **innodb_flush_log_at_trx_commit** 
- **LSN**
- **log_write_up_to()** 
- **assertion code**
- **write/flush**

※環境を整えて計測するなどは一切致しません、あくまでも記事内容を理解するために使用されている単語について調べた内容を記述します。

# MariaDB

MySQLは趣味で触ることが多いですが**MariaDB**についてはあまり知らないので軽く調べる。

## [Wiki](https://ja.wikipedia.org/wiki/MariaDB)

> **MariaDB**は、[MySQL](https://ja.wikipedia.org/wiki/MySQL)派生として開発されている、[オープンソース](https://ja.wikipedia.org/wiki/オープンソース)の[関係データベース管理システム](https://ja.wikipedia.org/wiki/関係データベース管理システム) (RDBMS) である。
>
> MariaDBの開発は、MySQLのオリジナルコードの作者で[MySQL AB](https://ja.wikipedia.org/wiki/MySQL_AB)の創設者でもある[ミカエル・ウィデニウス](https://ja.wikipedia.org/wiki/ミカエル・ウィデニウス)により、現在[オラクル](https://ja.wikipedia.org/wiki/オラクル_(企業))によって所有されているMySQLを[フォーク](https://ja.wikipedia.org/wiki/フォーク_(ソフトウェア開発))して立ち上げられたプロジェクトにより行われている[[6\]](https://ja.wikipedia.org/wiki/MariaDB#cite_note-6)。配布ライセンスは、[GNU General Public License](https://ja.wikipedia.org/wiki/GNU_General_Public_License)のバージョン2[[5\]](https://ja.wikipedia.org/wiki/MariaDB#cite_note-License-5)。

### 豆知識

いつ使えるかわからない豆知識としてWikiにも載っていた。

**MySQL**は、一番目の子供の名前らしいですね。

> MariaDBの名は、Wideniusの2番目の娘の名前から採られている[[7\]](https://ja.wikipedia.org/wiki/MariaDB#cite_note-7)。

## [日本語. *MariaDB* Knowledge Base ](https://mariadb.com/kb/ja/mariadb/)

詳しいことが知りたい方はこちらで。

## [**mariadb-10.5.9.tar.gz**](https://downloads.mariadb.org/mariadb/10.5.9/)

記事で、使用されていたファイル。

見たい方はこちらから。

現在公開されている最新バージョンみたいですね。

MySQLとほとんど同じと考えて良さそうですね。

なので、MySQL5系のリファレンスなどを参考にする場合があります。

MariaDBの基礎知識がわかったところで本編へ。

# fsync()

> **「fsync()を待つべきなのに待ってないから」**

元記事で一番重要と思われる**fsync()**という単語から調べます。

MariaDBにまつわる**fsync()**の記述は見つけられなかったが[Linux](https://kazmax.zpp.jp/cmd/f/fsync.2.html)と[Ubuntu](http://manpages.ubuntu.com/manpages/bionic/ja/man2/fsync.2.html)の２つOSについての記述を見つけた。

どちらも、**メモリ上のキャッシュデータから永続ストレージデバイスに 転送(フラッシュ)する**ことを指していました。

## メモリ

- データキャッシュ
- ログバッファ

殆どのRDBMSが、この2つに該当するメモリ領域を持っています。

### データキャッシュ

ディスクにあるデータの一部を保持するためのメモリ領域です。

SELCET文でデータ検索を行うときに、メモリ領域内に該当するデータがあると高速で処理が可能。

### ログバッファ

更新処理の実行に関係します。

DBMSは、更新SQL文を実行したときに即座にストレージ内のデータを変更していません。

このログバッファに更新情報を蓄積させて後でストレージへ変更を反映させます。

そして、**fsync**ではこのログバッファの処理が関係しています。

**ログバッファの内容をストレージ書き込む処理をfsyncということになります。**

# innodb_flush_log_at_trx_commit

記事では、この値が0,1,2のいずれでも同じ動作になると書いています。

[MySQL5.6 innodb_flush_log_at_trx_commit](https://dev.mysql.com/doc/refman/5.6/ja/innodb-parameters.html#sysvar_innodb_flush_log_at_trx_commit)

> [コミット](https://dev.mysql.com/doc/refman/5.6/ja/glossary.html#glos_commit)操作に対する厳密な [ACID](https://dev.mysql.com/doc/refman/5.6/ja/glossary.html#glos_acid) コンプライアンスと、コミット関連の I/O 操作が再編成およびバッチ処理されるときに実現可能な高いパフォーマンスとの間のバランスを制御します。デフォルト値を変更するとパフォーマンスを改善できますが、クラッシュ時にトランザクションが最大で 1 秒間失われる可能性があります。


## innodb_flush_log_at_trx_commit = 0

> 値を 0 にすると、約 1 秒ごとに 1 回、`InnoDB` のログバッファーの内容がログファイルに書き込まれ、ログファイルがディスクにフラッシュされます。

## innodb_flush_log_at_trx_commit = 0

> 完全に ACID コンプライアンスに従うには、デフォルト値の 1 を使用する必要があります。


## innodb_flush_log_at_trx_commit = 0

> 値を 2 にすると、トランザクションコミットのたびに、`InnoDB` のログバッファーの内容がログファイルに書き込まれ、約 1 秒ごとに 1 回ログファイルがディスクにフラッシュされます。

それぞれの値で、ログファイルに書き込むタイミングが変化します。

**ログファイルに書き込む処理を行うとファイルに対するI/Oのため低速になる。**

# LSN

>「ログシーケンス番号 (Log Sequence Number)」の頭字語。この任意の増加し続ける値は、**Redo ログ**に記録される操作に対応する時点を表します。(この時点は、**トランザクション**境界を意識しません。1 つ以上のトランザクションの中間になることがあります。)**クラッシュリカバリ**中に InnoDB によって内部的に、バッファープールを管理するために使用されます。

Redoログとの紐付けのために使用される番号となっている。

# log_write_up_to() 

[それっぽいやつ](https://programmerstart.com/article/27881471310/)があったのですが、ソースコード中の関数名かなと思います。

```
log_write_up_to(lsn, LOG_WAIT_ONE_GROUP, FALSE);
```

ソースコードとなると、これ以上踏み込むのは難しいので諦めます。

#  assertion code

[アサーション（ソフトウェア開発）](https://en.wikipedia.org/wiki/Assertion_(software_development))

> [コンピュータプログラミング](https://en.wikipedia.org/wiki/Computer_programming)使用する場合、具体的には[命令型プログラミングの](https://en.wikipedia.org/wiki/Imperative_programming)パラダイムを、**アサーションは、**ある[述語](https://en.wikipedia.org/wiki/Predicate_(mathematical_logic))（[ブール値関数](https://en.wikipedia.org/wiki/Boolean-valued_function)オーバー[状態空間](https://en.wikipedia.org/wiki/State_space)通常のように表現、[論理命題](https://en.wikipedia.org/wiki/Logical_proposition)用い[変数](https://en.wikipedia.org/wiki/Variable_(programming))プログラム内のポイントに接続された番組の）を、そのコード実行のその時点で常にtrueと評価される必要があります。アサーションは、プログラマーがコードを読んだり、コンパイラーがコードをコンパイルしたり、プログラムが自身の欠陥を検出したりするのに役立ちます

正常に作動しているかを確認するような使用方法なのかと認識しました。

>```
>mariadb-10.5.9> diff -up storage/innobase/log/log0log.cc.orig storage/innobase/log/log0log.cc
>--- storage/innobase/log/log0log.cc.orig        2021-03-02 12:04:30.167590939 +0900
>```

## [diffコマンド](https://www.atmarkit.co.jp/ait/articles/1704/13/news021.html)

Linux等で使用されるコマンド。

> 「diff」は、2つのテキストファイルを比較し、異なる箇所を出力するコマンドです。

| 短いオプション | 長いオプション    | 意味                                                         |
| :------------- | ----------------- | ------------------------------------------------------------ |
| -u             | --unified         | 違いのある箇所を1つにまとめて、-記号と+記号で変更箇所を示す（unified形式、[第103回参照](https://www.atmarkit.co.jp/ait/articles/1704/14/news011.html)） |
| -p             | --show-c-function | 変更がC言語のどの関数で行われたのかを表示する。「-F'^[_a-zA-Z$]'」相当 |

参照してたそれっぽいファイルは見つけた。

該当ファイルはC言語で記述されている。

[storage/innobase/log/log0log.cc.orig storage/innobase/log/log0log.cc](https://github.com/MariaDB/server/blob/10.6/storage/innobase/log/log0log.cc)

# write/flush

直接的な記述はなかったですがそれっぽい解釈は見つかりました。

## write

[MySQLとMariaDBの比較](https://www.system-exe.co.jp/dbexpert13/)

> テーブルへの挿入

## flush

​	[フラッシュ ](	https://www.wdic.org/w/TECH/%E3%83%95%E3%83%A9%E3%83%83%E3%82%B7%E3%83%A5%20%28%E5%87%A6%E7%90%86%29)

> [バッファー](https://www.wdic.org/w/TECH/バッファー)内に貯められた情報を吐き出すこと。[英語](https://www.wdic.org/w/CUL/英語)の原義で、流す、追い出す、平らにする。

# おまけ

MariaDBがはやいかどうかの記事を探してみた。

[MariaDB vs MySQL: 徹底比較](https://www.xplenty.com/jp/blog/mariadb-vs-mysql-everything-you-need-to-know-ja/#:~:text=MariaDB%E3%81%AF%E5%AE%8C%E5%85%A8%E3%81%AB%E3%82%AA%E3%83%BC%E3%83%97%E3%83%B3,%E3%81%82%E3%82%8B%E3%81%93%E3%81%A8%E3%81%8C%E5%A4%9A%E3%81%84%E3%81%A7%E3%81%99%E3%80%82)

# 〆

それぞれの単語を調べて改めて記事を読むとより理解が深まった。

読んですぐ理解できるようにこれからもっと頑張りたいと思った。

[Yasufumi Kinoshita](https://draft.blogger.com/profile/12171410795395824277)さんは他に様々なDBの記事があるので読んでみると面白いです。