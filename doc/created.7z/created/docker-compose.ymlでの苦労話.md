# 目次
[:contents]

# とある日



Oracleを使っていたが、Oracle clientがうまく行かなかったので、MySQLに変更して開発を行うことにした。

ってことで、前に、Dockerを使ってMySQLの環境を構築したものを使おうと思い、

テスト環境と本番環境と2つ用意したかったので、docker内でもう一つ立てようとした。

その時起こった、苦労したお話。

# テスト環境と本番環境の2つのMySQL構築

テスト環境と本番環境の2つがほしいためdockerを使用して、構築しようと思った。

Dockerの構築は自分で書いた前の記事参考にしながら、順調に進んでいた。

そして、いざ起動しようとして下記のコマンドを実行した。

<div class="code-title" data-title="sh">
```sh
docker exec -it mysql1 mysql -u root -p
```
</div>

あとは、パスワード打てばつながると思ったら。

<div class="code-title" data-title="mysql">
```mysql
ERROR 1045 (28000): Access denied for user 'root'@'localhost' (using password: YES)
```
</div>

あれ？**つながらない**。

なんでだろう。

この環境停止して。

前に作成した環境につなげてみたら、問題なかった。

あれと思って、色々調べながらやってみたら。

Dockerで複数の同じサービス環境を建てることはできないし、2つの環境をを実行するときに1つ目の環境を参照してしまう問題だと発覚した。

え、**じゃあ複数の環境を構築するの**ってどうやるのってなった。

## docker-composeで解決

本を参考にしながら、Dockerを使用したので知らなかったが、複数の環境を構築したいのであれば管理する別のシステムである、Docker-composeを使うのがいいらしい。

docker-composeで、MySQLを構築した感じ、作成したい環境ごとにファイルを作成して立てていて、それぞれが独立している。

フォルダ構成や設定ファイルを自分で作成するので、手間が増えることになるが慣れれば簡単そう。

docker-composeでMySQLを構築したがそれは別の記事で書こうと思う。

# docker-composeの手間

docker-composeは、ymlファイルやデータを格納するファイルを自ら作成しなくてはならない。

参考にしていた、サイトには普通にそういった記述がしてあって、え、これつくるの・・・。ってなった。

## docker-compose.ymlのVersion違い

docker-compose.ymlが必要なのは調べててわかったので、1から記述するのは大変なのでそれっぽいやつをコピーさせてもらってやってみたら、全然できない。

docker-compose.ymlには記述方式が、versionごとに変わるらしく。

自分の環境では、実行できなかった。

でも、Dockerのリファレンスは日本語でわかりやすかった。

が、設定項目が多すぎて必要項目を探すのははじめのうちはとても苦労する。



<div class="code-title" data-title="yaml">
```yaml
version: "3.8"
services:
  db:
    image: mysql/mysql-server
    restart: always
    environment:
      MYSQL_ROOT_PASSWORD: Dockermysql-test
      MYSQL_DATABASE: test
      MYSQL_USER: test
      MYSQL_PASSWORD: test
      TZ: "Asia/Tokyo"
      MYSQL_PORT: 3306
    ports:
      - 3306:3306
    volumes:
      - ./db/mysql_data:/var/lib/mysql
      - ./docker/db/my.cnf:/etc/my.cnf
```
</div>

こんな感じで、自分は構築してみた。

# 原因わかって自分馬鹿だなって思ったこと

Dockerを起動するときに行うコマンド。

<div class="code-title" data-title="sh">
```sh
docker exec -it mysql1 mysql -u root -p
```
</div>

これをずっと。

<div class="code-title" data-title="sh">
```sh
docker-compose exec -it mysql1 mysql -u root -p
```
</div>

とやってた。

これコマンドエラーが出なく、実行できない的なエラーが表示されてた。

だから、悩みに悩んだ。

# 〆

Docker初心者の自分が、構築してて遭遇した苦労話をまとめてみた。

現在も、構築中で完成はしていないがほんとに大変だなと思う。