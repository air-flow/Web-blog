# 目次
[:contents]

# とある日

https://speakerdeck.com/yoku0825/bokugakangaetasaikiyoufalsemysqlfalsejian-shi-sukuriputowodu-mijie-ku?slide=29

を見てて、監視とは行かないが簡単にチェックできそうなものをいくつかやってみようかと思います。

# 環境

| 項目     | 詳細         |
| -------- | ------------ |
| DataBase | MySQL 8.0.23 |
| OS       | CentOS8      |

詳しくは下記のテスト環境の記事を参照してください。

[https://updraft.hatenadiary.com/entry/2021/01/21/075228:embed:cite]

# ロングクエリー監視

<div class="code-title" data-title="mysql">
```mysql
mysql> show full processlist \G;
*************************** 1. row ***************************
     Id: 7
   User: event_scheduler
   Host: localhost
     db: NULL
Command: Daemon
   Time: 235872
  State: Waiting on empty queue
   Info: NULL
*************************** 2. row ***************************
     Id: 68
   User: root
   Host: localhost:39130
     db: hobby
Command: Sleep
   Time: 23216
  State:
   Info: NULL
*************************** 3. row ***************************
     Id: 69
   User: root
   Host: localhost:39132
     db: hobby
Command: Sleep
   Time: 17907
  State:
   Info: NULL
*************************** 4. row ***************************
     Id: 70
   User: root
   Host: localhost:39134
     db: hobby
Command: Sleep
   Time: 7471
  State:
   Info: NULL
*************************** 5. row ***************************
     Id: 77
   User: root
   Host: localhost
     db: NULL
Command: Query
   Time: 0
  State: init
   Info: show full processlist
5 rows in set (0.00 sec)

```
</div>

## ロングクエリー確認

実際に、ロングクエリーを発行した場合どうのようなデータが有るのかを確認します。

簡単な時間がかかるクエリーを実行します。

<div class="code-title" data-title="sql">
```sql
select SLEEP(10000);
```
</div>

結果↓

<div class="code-title" data-title="mysql">
```mysql
*************************** 8. row ***************************
     Id: 80
   User: root
   Host: localhost:39222
     db: hobby
Command: Query
   Time: 16
  State: User sleep
   Info: /* ApplicationName=DBeaver 7.2.0 - SQLEditor <Script-25.sql> */ select SLEEP(10000)
LIMIT 0, 200
8 rows in set (0.00 sec)
```
</div>

## Commandについて

[8.14.2スレッドコマンド値](https://dev.mysql.com/doc/refman/8.0/en/thread-commands.html)

**`show full processlist \G`**の`Command`結果である3つだけ引用します。

その他については、上記のリファレンスを参照してください。

- Daemon

  >このスレッドはサーバーの内部にあり、クライアント接続にサービスを提供するスレッドではありません。

- Query

  >シングルスレッドレプリケーションアプライヤースレッドおよびレプリケーションコーディネータースレッドによるクエリの実行中にユーザークライアントに使用されます。

- Sleep

  >スレッドは、クライアントが新しいステートメントを送信するのを待っています。

`Sleep`は、接続を切り忘れた物がずっと残ってる感じですね。

# コネクション数監視



<div class="code-title" data-title="mysql">
```mysql
mysql> show global status like 'Threads_connected';
+-------------------+-------+
| Variable_name     | Value |
+-------------------+-------+
| Threads_connected | 4     |
+-------------------+-------+
1 row in set (0.00 sec)

mysql> show global variables like 'max_connections';
+-----------------+-------+
| Variable_name   | Value |
+-----------------+-------+
| max_connections | 151   |
+-----------------+-------+
1 row in set (0.00 sec)
```
</div>

## [Threads_connected](https://dev.mysql.com/doc/refman/8.0/en/server-status-variables.html#statvar_Threads_connected)

現在開いている接続の数。

## [max_connections](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_max_connections)

| コマンドライン形式                                           | `--max-connections=#` |
| :----------------------------------------------------------- | --------------------- |
| システム変数                                                 | `max_connections`     |
| 範囲                                                         | グローバル            |
| 動的                                                         | はい                  |
| [`SET_VAR`](https://dev.mysql.com/doc/refman/8.0/en/optimizer-hints.html#optimizer-hints-set-var) ヒントが適用されます | 番号                  |
| タイプ                                                       | 整数                  |
| デフォルト値                                                 | `151`                 |
| 最小値                                                       | `1`                   |
| 最大値                                                       | `100000`              |

同時クライアント接続の最大許容数。詳細については、[5.1.12.1項「接続インターフェース」を](https://dev.mysql.com/doc/refman/8.0/en/connection-interfaces.html)参照してください 。

# AUTO_INCREMENT監視

<div class="code-title" data-title="mysql">
```mysql
mysql> select table_schema AS table_schema , table_name AS table_name, column_name AS column_name , auto_increment AS auto_increment, column_type AS column_type from information_schema.tables join information_schema.columns using (table_schema, table_name ) where table_schema not in ('mysql' , 'information_schema','performance_schema', 'sys') and table_type = 'BASE TABLE ' AND auto_increment is not null and extra = 'auto_increment'\G;
*************************** 1. row ***************************
  table_schema: ai
    table_name: categorys
   column_name: category_id
auto_increment: 6
   column_type: bigint
*************************** 2. row ***************************
  table_schema: ai
    table_name: dialogues
   column_name: dialogue_id
auto_increment: 59
   column_type: bigint
*************************** 3. row ***************************
  table_schema: ai
    table_name: genders
   column_name: gender_id
auto_increment: 3
   column_type: bigint
*************************** 4. row ***************************
  table_schema: ai
    table_name: message_historys
   column_name: history_id
auto_increment: 30820
   column_type: bigint
*************************** 5. row ***************************
  table_schema: ai
    table_name: types
   column_name: type_id
auto_increment: 2
   column_type: bigint
*************************** 6. row ***************************
  table_schema: ai
    table_name: users
   column_name: user_id
auto_increment: 10322
   column_type: bigint
*************************** 7. row ***************************
  table_schema: hobby
    table_name: number_test
   column_name: id
auto_increment: 2
   column_type: bigint
*************************** 8. row ***************************
  table_schema: hobby
    table_name: temp_version
   column_name: id
auto_increment: 157448
   column_type: bigint
*************************** 9. row ***************************
  table_schema: hobby
    table_name: temp
   column_name: id
auto_increment: 256
   column_type: bigint
*************************** 10. row ***************************
  table_schema: hobby
    table_name: date_version
   column_name: id
auto_increment: 1048561
   column_type: bigint
*************************** 11. row ***************************
  table_schema: hobby
    table_name: var_version
   column_name: id
auto_increment: 1000001
   column_type: bigint
*************************** 12. row ***************************
  table_schema: leetcode
    table_name: employee
   column_name: id
auto_increment: 3
   column_type: int
*************************** 13. row ***************************
  table_schema: hobby
    table_name: auto_increment_test2
   column_name: id
auto_increment: 11
   column_type: int
*************************** 14. row ***************************
  table_schema: d1
    table_name: t1
   column_name: num
auto_increment: 20026855
   column_type: int
*************************** 15. row ***************************
  table_schema: hobby
    table_name: auto_increment_test
   column_name: id
auto_increment: 5
   column_type: int
*************************** 16. row ***************************
  table_schema: hobby
    table_name: ran_mem
   column_name: i
auto_increment: 1966066
   column_type: int
*************************** 17. row ***************************
  table_schema: hobby
    table_name: null_index
   column_name: id
auto_increment: 131071
   column_type: int
*************************** 18. row ***************************
  table_schema: hobby
    table_name: char_index
   column_name: id
auto_increment: 131071
   column_type: int
*************************** 19. row ***************************
  table_schema: hobby
    table_name: bool_index
   column_name: id
auto_increment: 131071
   column_type: int
*************************** 20. row ***************************
  table_schema: hobby
    table_name: join1
   column_name: join1_id
auto_increment: 5
   column_type: int
*************************** 21. row ***************************
  table_schema: hobby
    table_name: join2
   column_name: join2_id
auto_increment: 5
   column_type: int
*************************** 22. row ***************************
  table_schema: hobby
    table_name: sya
   column_name: sya_id
auto_increment: 4
   column_type: int
*************************** 23. row ***************************
  table_schema: hobby
    table_name: syain
   column_name: syain_id
auto_increment: 5
   column_type: int
*************************** 24. row ***************************
  table_schema: hobby
    table_name: sosiki
   column_name: sosiki_id
auto_increment: 4
   column_type: int
24 rows in set (0.00 sec)
```
</div>

# UPTIME監視

<div class="code-title" data-title="mysql">
```mysql
mysql> show global status like 'Uptime';
+---------------+--------+
| Variable_name | Value  |
+---------------+--------+
| Uptime        | 239199 |
+---------------+--------+
1 row in set (0.00 sec)
```
</div>

## [Uptime](https://dev.mysql.com/doc/refman/8.0/en/server-status-variables.html#statvar_Uptime)

サーバーが稼働していた秒数。

# history_list_length監視

<div class="code-title" data-title="mysql">
```mysql
mysql> select name, count from information_schema.innodb_metrics where name = 'trx_rseg_history_len';
+----------------------+-------+
| name                 | count |
+----------------------+-------+
| trx_rseg_history_len |     0 |
+----------------------+-------+
1 row in set (0.01 sec)
```
</div>

## [15.8.9構成のパージ](https://dev.mysql.com/doc/refman/8.0/en/innodb-purge-configuration.html)

<div class="code-title" data-title="mysql">
```mysql
mysql> SHOW ENGINE INNODB STATUS\G;
------------
TRANSACTIONS
------------
Trx id counter 16716
Purge done for trx's n:o < 16713 undo n:o < 0 state: running but idle
History list length 0
```
</div>

[InnoDB履歴リストの長さはどれくらいですか？](https://vividcortex.com/blog/2015/07/20/what-is-innodb-history-list-length/)

`trx_rseg_history_len`や`History list length`単体での詳しい解説はあまり見つからなかったので、英語の記事にはなりますがそれらしい記事を見つけたので貼っておきます。

今後詳しく調べてみたいです。

# 〆

今回は、yoku0825さんの「ぼくがかんがえたさいきょうのMySQLの監視スクリプトを読み解く」を読み解いてみました。

あくまで各監視内容をサクッと見ただけの内容にはなってしまいましたが、今後もっと詳しく調べたいです。

`MySQL`にはまだまだ知らないことが多いです。

ぜひ、「ぼくがかんがえたさいきょうのMySQLの監視スクリプトを読み解く」も見てみてください。

他にもいろいろな監視について書かれています。

