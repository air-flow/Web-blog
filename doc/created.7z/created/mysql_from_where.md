# 目次
[:contents]

# とある日

https://twitter.com/atsuizo/status/1382630545042014211?s=20

<div class="code-title" data-title="reStructuredText">
```reStructuredText
MySQLで、
select sleep(10);
と
select count(*) from (select sleep(10)) a;
は
sleep(10)が発動して
「1 row in set (10.01 sec)」
になるけど、
select count(*) from (select sleep(10) where 1=2) a;
は
sleep(10)が発動しなくて
1 row in set (0.00 sec)
になる。

という小ネタ。
```
</div>

今回調べるのは、sleepの小ネタではなくFROM句がなくてどこまでSQLを記述できるのかを調べます。

純粋にFROM句がないSQLが不自然極まりなく気になったのでくだらないことですが気になります。

# MySQL

## SELECT 

<div class="code-title" data-title="mysql">
```mysql
mysql> select 1;
+---+
| 1 |
+---+
| 1 |
+---+
1 row in set (0.00 sec)
```
</div>

## WHERE

<div class="code-title" data-title="mysql">
```mysql
mysql> select 1 where 0 = 0;
+---+
| 1 |
+---+
| 1 |
+---+
1 row in set (0.00 sec)
```
</div>

## GROUP BY

<div class="code-title" data-title="mysql">
```mysql
mysql> select 1 where 0 = 0 group by 1;
+---+
| 1 |
+---+
| 1 |
+---+
1 row in set (0.00 sec)
```
</div>

## HAVING

<div class="code-title" data-title="mysql">
```mysql
mysql> select 1 where 0 = 0 group by 1 having count(1) = 0;
+---+
| 1 |
+---+
| 1 |
+---+
1 row in set (0.00 sec)
```
</div>

## ORDER BY

<div class="code-title" data-title="mysql">
```mysql
mysql> select 1 where 0 = 0 group by 1 having count(1) = 0 order by 1;
+---+
| 1 |
+---+
| 1 |
+---+
1 row in set (0.00 sec)
```
</div>

# 〆 

**FROM句**なしでSQLを記述することってまったくないため気になったので調べてみた。

